@file:OptIn(ExperimentalMaterial3Api::class, ExperimentalFoundationApi::class)

package com.example.encnotes

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.fragment.app.FragmentActivity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@Composable
fun OnboardingScreen() {
    val scope = rememberCoroutineScope()
    val pager = rememberPagerState(pageCount = { 4 })
    val pages = listOf(
        tr("Що це", "What is this") to tr(
            "Офлайн-блокнот для паролів, кодів і конфіденційних нотаток. Усе зберігається лише на вашому телефоні й шифрується. Інтернет не використовується.",
            "An offline notebook for passwords, codes and private notes. Everything stays on your phone, encrypted. No internet is used."
        ),
        tr("PIN і ключ", "PIN and key") to tr(
            "PIN (4–6 цифр) лише відкриває застосунок. \"Ключ\" — будь-який текст, цифри чи символи. Без ключа ніхто не побачить справжній текст нотаток, навіть знаючи PIN.",
            "The PIN (4–6 digits) only opens the app. The \"key\" is any text, digits or symbols. Without the key nobody can see the real text, even knowing the PIN."
        ),
        tr("Що буде, якщо забути ключ", "If you forget the key") to tr(
            "Відновити PIN або ключ неможливо — нікому, навіть авторам. Нотатки назавжди залишаться зашифрованими. Запам'ятайте їх!",
            "PIN or key cannot be recovered — by anyone. The notes will stay encrypted forever. Remember them!"
        ),
        tr("Як перенести нотатки", "How to move notes") to tr(
            "Меню → Експорт дасть шифрований текст. Скопіюйте його, а в іншому екземплярі застосунку: Меню → Імпорт і введіть той самий ключ.",
            "Menu → Export gives encrypted text. Copy it, then in another copy of the app: Menu → Import and enter the same key."
        )
    )
    Scaffold(containerColor = MaterialTheme.colorScheme.background) { pad ->
        Column(Modifier.padding(pad).fillMaxSize()) {
            HorizontalPager(pager, Modifier.weight(1f)) { i ->
                Column(
                    Modifier.fillMaxSize().padding(32.dp),
                    verticalArrangement = Arrangement.Center,
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(pages[i].first, style = MaterialTheme.typography.headlineMedium, textAlign = TextAlign.Center)
                    Spacer(Modifier.height(16.dp))
                    Text(pages[i].second, style = MaterialTheme.typography.bodyLarge, textAlign = TextAlign.Center)
                }
            }
            Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                TextButton(onClick = {
                    App.lang = if (App.lang == "uk") "en" else "uk"
                    Store.prefs.edit().putString("lang", App.lang).apply()
                }) { Text(if (App.lang == "uk") "English" else "Українська") }
                Spacer(Modifier.weight(1f))
                Text("${pager.currentPage + 1}/4")
                Spacer(Modifier.width(16.dp))
                Button(onClick = {
                    if (pager.currentPage < 3) scope.launch { pager.animateScrollToPage(pager.currentPage + 1) }
                    else App.screen = Screen.Setup
                }) { Text(if (pager.currentPage < 3) tr("Далі", "Next") else tr("Почати", "Start")) }
            }
        }
    }
}

@Composable
fun SetupScreen() {
    val scope = rememberCoroutineScope()
    var pin by remember { mutableStateOf("") }
    var pin2 by remember { mutableStateOf("") }
    var key by remember { mutableStateOf("") }
    var showKey by remember { mutableStateOf(false) }
    var err by remember { mutableStateOf<String?>(null) }
    var busy by remember { mutableStateOf(false) }
    var warn by remember { mutableStateOf(false) }
    Scaffold(containerColor = MaterialTheme.colorScheme.background) { pad ->
        Column(
            Modifier.padding(pad).padding(24.dp).verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text(tr("Створіть PIN і ключ", "Create PIN and key"), style = MaterialTheme.typography.headlineSmall)
            Field(tr("PIN (4–6 цифр)", "PIN (4–6 digits)"), pin, { pin = it.filter { c -> c in '0'..'9' }.take(6) }, secret = true, numeric = true,
                help = tr("PIN лише відкриває застосунок. Лише цифри, від 4 до 6.", "The PIN only opens the app. Digits only, 4 to 6."))
            Field(tr("Повторіть PIN", "Repeat PIN"), pin2, { pin2 = it.filter { c -> c in '0'..'9' }.take(6) }, secret = true, numeric = true)
            Field(tr("Ключ (текст, цифри, символи)", "Key (text, digits, symbols)"), key, { key = it }, secret = !showKey,
                help = tr("Ключ потрібен, щоб побачити справжній текст нотаток. Будь-які символи. Чим довший — тим надійніший.",
                    "The key is needed to see the real text of notes. Any characters. The longer, the safer."))
            Row(Modifier.fillMaxWidth().clickable { showKey = !showKey }, verticalAlignment = Alignment.CenterVertically) {
                Checkbox(checked = showKey, onCheckedChange = { showKey = it })
                Text(tr("Показати ключ", "Show key"))
            }
            err?.let { Text(it, color = MaterialTheme.colorScheme.error) }
            Button(enabled = !busy, modifier = Modifier.fillMaxWidth().height(52.dp), onClick = {
                err = when {
                    pin.length !in 4..6 -> tr("PIN має містити від 4 до 6 цифр.", "PIN must have 4 to 6 digits.")
                    pin != pin2 -> tr("PIN не збігається. Спробуйте ще раз.", "PINs do not match. Try again.")
                    key.isEmpty() -> tr("Введіть ключ.", "Enter the key.")
                    else -> null
                }
                if (err == null) scope.launch {
                    busy = true
                    val v = withContext(Dispatchers.Default) { Auth.setup(pin, key) }
                    busy = false
                    App.pin = pin; App.vault = v
                    warn = true
                }
            }) {
                if (busy) {
                    CircularProgressIndicator(Modifier.size(22.dp), strokeWidth = 2.dp, color = MaterialTheme.colorScheme.onPrimary)
                    Spacer(Modifier.width(12.dp))
                    Text(tr("Створюємо ключі…", "Creating keys…"))
                } else Text(tr("Створити", "Create"))
            }
        }
    }
    if (warn) {
        AlertDialog(
            onDismissRequest = {},
            title = { Text(tr("Важливо", "Important")) },
            text = { Text(tr("Якщо ви забудете PIN або ключ, відновити нотатки буде неможливо.",
                "If you forget the PIN or key, the notes cannot be recovered.")) },
            confirmButton = { Button(onClick = { warn = false; App.screen = Screen.Notes }) { Text(tr("Я розумію", "I understand")) } }
        )
    }
}

@Composable
fun LoginScreen(act: FragmentActivity) {
    val scope = rememberCoroutineScope()
    var pin by remember { mutableStateOf("") }
    var err by remember { mutableStateOf<String?>(null) }
    var ver by remember { mutableIntStateOf(0) }
    var busy by remember { mutableStateOf(false) }
    val rem = rememberRemaining(Auth.pinLock, ver)

    fun attempt(p: String) {
        if (Auth.pinLock.remainingMs() > 0 || busy) return
        scope.launch {
            busy = true
            val ok = withContext(Dispatchers.Default) { Auth.checkPin(p) }
            busy = false
            if (ok) {
                Auth.pinLock.reset()
                App.pin = p; App.vault = null
                App.screen = Screen.Notes
            } else {
                val left = Auth.pinLock.fail()
                ver++
                pin = ""
                err = if (left > 0) tr("Невірний PIN. Залишилось спроб: $left", "Wrong PIN. Attempts left: $left") else null
            }
        }
    }
    LaunchedEffect(Unit) { if (Bio.enabled && rem <= 0) Bio.login(act) { attempt(it.substringBefore(':')) } }

    Scaffold(containerColor = MaterialTheme.colorScheme.background) { pad ->
        Column(
            Modifier.padding(pad).fillMaxSize().padding(32.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text("🔒", style = MaterialTheme.typography.displayMedium)
            Spacer(Modifier.height(8.dp))
            Text(tr("Шифрований блокнот", "Encrypted Notebook"), style = MaterialTheme.typography.headlineSmall)
            Spacer(Modifier.height(24.dp))
            if (rem > 0) {
                Text(tr("Забагато спроб. Спробуйте через ${fmt(rem)}", "Too many attempts. Try again in ${fmt(rem)}"),
                    color = MaterialTheme.colorScheme.error, textAlign = TextAlign.Center)
            } else {
                Field(tr("PIN", "PIN"), pin, { pin = it.filter { c -> c in '0'..'9' }.take(6) }, secret = true, numeric = true)
                err?.let { Spacer(Modifier.height(8.dp)); Text(it, color = MaterialTheme.colorScheme.error, textAlign = TextAlign.Center) }
                Spacer(Modifier.height(16.dp))
                Button(enabled = !busy && pin.length >= 4, modifier = Modifier.fillMaxWidth().height(52.dp), onClick = { attempt(pin) }) {
                    if (busy) CircularProgressIndicator(Modifier.size(22.dp), strokeWidth = 2.dp, color = MaterialTheme.colorScheme.onPrimary)
                    else Text(tr("Увійти", "Unlock"))
                }
                if (Bio.enabled) {
                    TextButton(onClick = { Bio.login(act) { attempt(it.substringBefore(':')) } }) { Text(tr("Відбиток / обличчя", "Fingerprint / face")) }
                }
            }
        }
    }
}

/** Одноразовий перехід зі старого формату: нотатки зберігаються. */
@Composable
fun MigrateScreen() {
    val scope = rememberCoroutineScope()
    var pin by remember { mutableStateOf("") }
    var key by remember { mutableStateOf("") }
    var err by remember { mutableStateOf<String?>(null) }
    var ver by remember { mutableIntStateOf(0) }
    var busy by remember { mutableStateOf(false) }
    val rem = rememberRemaining(Auth.pinLock, ver)
    Scaffold(containerColor = MaterialTheme.colorScheme.background) { pad ->
        Column(
            Modifier.padding(pad).fillMaxSize().padding(32.dp).verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(tr("Оновлення захисту", "Security update"), style = MaterialTheme.typography.headlineSmall)
            Spacer(Modifier.height(12.dp))
            Text(tr("Новий формат: PIN лише відкриває застосунок, а ключ питається лише для перегляду. Один раз введіть ваші поточні PIN і ключ — нотатки збережуться.",
                "New format: the PIN only opens the app and the key is asked only to view notes. Enter your current PIN and key once — your notes will be kept."),
                textAlign = TextAlign.Center)
            Spacer(Modifier.height(20.dp))
            if (rem > 0) {
                Text(tr("Забагато спроб. Спробуйте через ${fmt(rem)}", "Too many attempts. Try again in ${fmt(rem)}"),
                    color = MaterialTheme.colorScheme.error, textAlign = TextAlign.Center)
            } else {
                Field(tr("PIN", "PIN"), pin, { pin = it.filter { c -> c in '0'..'9' }.take(6) }, secret = true, numeric = true)
                Spacer(Modifier.height(8.dp))
                Field(tr("Ключ (число)", "Key (number)"), key, { key = it.filter { c -> c in '0'..'9' }.take(18) }, secret = true, numeric = true)
                err?.let { Spacer(Modifier.height(8.dp)); Text(it, color = MaterialTheme.colorScheme.error, textAlign = TextAlign.Center) }
                Spacer(Modifier.height(16.dp))
                Button(enabled = !busy && pin.length >= 4 && key.isNotEmpty(), modifier = Modifier.fillMaxWidth().height(52.dp), onClick = {
                    scope.launch {
                        busy = true
                        val ok = Auth.migrate(pin, key)
                        busy = false
                        if (ok) {
                            Auth.pinLock.reset()
                            App.screen = Screen.Notes
                        } else {
                            val left = Auth.pinLock.fail()
                            ver++; pin = ""; key = ""
                            err = if (left > 0) tr("Невірний PIN або ключ. Залишилось спроб: $left", "Wrong PIN or key. Attempts left: $left") else null
                        }
                    }
                }) {
                    if (busy) {
                        CircularProgressIndicator(Modifier.size(22.dp), strokeWidth = 2.dp, color = MaterialTheme.colorScheme.onPrimary)
                        Spacer(Modifier.width(12.dp))
                        Text(tr("Оновлюємо…", "Updating…"))
                    } else Text(tr("Оновити", "Update"))
                }
            }
        }
    }
}

@Composable
fun HelpScreen() {
    BackHandler { App.screen = Screen.Settings }
    Scaffold(containerColor = MaterialTheme.colorScheme.background, topBar = {
        TopAppBar(
            title = { Text(tr("Довідка", "Help")) },
            navigationIcon = { IconButton(onClick = { App.screen = Screen.Settings }) { Icon(Icons.AutoMirrored.Filled.ArrowBack, null) } }
        )
    }) { pad ->
        Text(helpText(), Modifier.padding(pad).padding(16.dp).verticalScroll(rememberScrollState()))
    }
}

@Composable
fun SettingsScreen(act: FragmentActivity) {
    BackHandler { App.screen = Screen.Notes }
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var autolock by remember { mutableIntStateOf(Store.prefs.getInt("autolock", 5)) }
    var bio by remember { mutableStateOf(Bio.enabled) }
    // зміна ключа / режиму
    var curKey by remember { mutableStateOf("") }
    var newMode by remember { mutableStateOf(Auth.mode()) }
    var newKey by remember { mutableStateOf("") }
    var showNew by remember { mutableStateOf(false) }
    var kmsg by remember { mutableStateOf<String?>(null) }
    var kbusy by remember { mutableStateOf(false) }
    var curMode by remember { mutableStateOf(Auth.mode()) }
    // зміна PIN
    var oldPin by remember { mutableStateOf("") }
    var pinKey by remember { mutableStateOf("") }
    var newPin by remember { mutableStateOf("") }
    var pmsg by remember { mutableStateOf<String?>(null) }
    var pbusy by remember { mutableStateOf(false) }

    fun tooMany(): String? {
        val r = Auth.keyLock.remainingMs()
        return if (r > 0) tr("Забагато спроб. Спробуйте через ${fmt(r)}", "Too many attempts. Try again in ${fmt(r)}") else null
    }
    fun wrongKey(): String {
        val left = Auth.keyLock.fail()
        return if (left > 0) tr("Невірний ключ або PIN. Залишилось спроб: $left", "Wrong key or PIN. Attempts left: $left")
        else tr("Забагато спроб. Блокування на 10 хвилин.", "Too many attempts. Locked for 10 minutes.")
    }

    Scaffold(containerColor = MaterialTheme.colorScheme.background, topBar = {
        TopAppBar(
            title = { Text(tr("Налаштування", "Settings")) },
            navigationIcon = { IconButton(onClick = { App.screen = Screen.Notes }) { Icon(Icons.AutoMirrored.Filled.ArrowBack, null) } }
        )
    }) { pad ->
        Column(
            Modifier.padding(pad).padding(16.dp).verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Text(tr("Мова", "Language"), style = MaterialTheme.typography.titleMedium)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("uk" to "Українська", "en" to "English").forEach { (c, n) ->
                    FilterChip(selected = App.lang == c, onClick = {
                        App.lang = c; Store.prefs.edit().putString("lang", c).apply()
                    }, label = { Text(n) })
                }
            }

            Text(tr("Автоблокування після виходу", "Auto-lock after leaving"), style = MaterialTheme.typography.titleMedium)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                listOf(0, 1, 5, 15).forEach { m ->
                    FilterChip(selected = autolock == m, onClick = {
                        autolock = m; Store.prefs.edit().putInt("autolock", m).apply()
                    }, label = { Text(if (m == 0) tr("Одразу", "Instantly") else tr("$m хв", "$m min")) })
                }
                Help(tr("Через скільки часу після виходу із застосунку знадобиться знову ввести PIN (і ключ). Поки ви в застосунку — він не блокується.",
                    "How long after leaving the app you must enter the PIN (and key) again. While you are in the app it does not lock."))
            }

            if (Bio.available(ctx)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(tr("Вхід за відбитком / обличчям", "Fingerprint / face unlock"), Modifier.weight(1f))
                    Switch(checked = bio, onCheckedChange = { on ->
                        if (on) {
                            val p = App.pin
                            if (p != null) Bio.enable(act, p) { ok -> bio = ok }
                        } else { Bio.disable(); bio = false }
                    })
                }
            }

            HorizontalDivider(Modifier.padding(vertical = 8.dp))
            Text(tr("Ключ і режим шифрування", "Key and encryption mode"), style = MaterialTheme.typography.titleMedium)
            Text(
                if (curMode == "C1") tr("Зараз: Простий зсув (Цезар)", "Now: Simple shift (Caesar)")
                else tr("Зараз: Надійний (AES-256)", "Now: Reliable (AES-256)"),
                style = MaterialTheme.typography.bodyMedium
            )
            Field(tr("Поточний ключ", "Current key"), curKey, { curKey = it }, secret = true,
                help = tr("Щоб змінити ключ чи режим, спершу введіть поточний ключ.", "To change the key or mode, first enter the current key."))
            Row(Modifier.fillMaxWidth().clickable { newMode = "A2" }, verticalAlignment = Alignment.CenterVertically) {
                RadioButton(selected = newMode == "A2", onClick = { newMode = "A2" })
                Text(tr("Надійний (рекомендовано) — ключ: будь-який текст і символи", "Reliable (recommended) — key: any text and symbols"), Modifier.weight(1f))
                Help(tr("Сучасне сильне шифрування AES-256. Захищає, навіть якщо хтось отримає файл бази даних.",
                    "Modern strong AES-256 encryption. Protects even if someone gets the database file."))
            }
            Row(Modifier.fillMaxWidth().clickable { newMode = "C1"; newKey = "" }, verticalAlignment = Alignment.CenterVertically) {
                RadioButton(selected = newMode == "C1", onClick = { newMode = "C1"; newKey = "" })
                Text(tr("Простий зсув (Цезар) — ключ: лише цифри", "Simple shift (Caesar) — key: digits only"), Modifier.weight(1f))
                Help(tr("Просте перемішування символів. Ключ — лише цифри (наприклад 100 → зсув 7). НЕ захищає від серйозного злому. Ключ потрібен навіть для створення нотаток.",
                    "Simple character shuffling. The key is digits only (e.g. 100 → shift 7). Does NOT protect against serious attacks. The key is needed even to create notes."))
            }
            if (newMode == "C1") {
                Text(tr("Увага: Цезар НЕ захищає від серйозного злому. Не зберігайте в ньому важливі паролі.",
                    "Warning: Caesar does NOT protect against serious attacks. Do not store important passwords with it."),
                    color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
            }
            val numeric = newMode == "C1"
            Field(tr("Новий ключ", "New key"), newKey, { newKey = if (numeric) it.filter { c -> c in '0'..'9' }.take(18) else it },
                secret = !showNew, numeric = numeric)
            Row(Modifier.fillMaxWidth().clickable { showNew = !showNew }, verticalAlignment = Alignment.CenterVertically) {
                Checkbox(checked = showNew, onCheckedChange = { showNew = it })
                Text(tr("Показати новий ключ", "Show new key"))
            }
            kmsg?.let { Text(it) }
            Button(enabled = !kbusy, modifier = Modifier.fillMaxWidth(), onClick = {
                val t = tooMany()
                if (t != null) kmsg = t
                else if (curKey.isEmpty()) kmsg = tr("Введіть поточний ключ.", "Enter the current key.")
                else if (!Auth.validKey(newMode, newKey)) {
                    kmsg = if (numeric) tr("Для Цезаря ключ — лише цифри (до 18).", "For Caesar the key is digits only (up to 18).")
                    else tr("Введіть новий ключ.", "Enter a new key.")
                }
                else scope.launch {
                    kbusy = true
                    val ok = Auth.changeKey(curKey, newMode, newKey)
                    kbusy = false
                    if (ok) {
                        Auth.keyLock.reset()
                        curMode = newMode
                        kmsg = tr("Готово: ключ і режим змінено.", "Done: key and mode changed.")
                        curKey = ""; newKey = ""
                    } else kmsg = wrongKey()
                }
            }) { Text(if (kbusy) tr("Зачекайте…", "Please wait…") else tr("Змінити ключ / режим", "Change key / mode")) }

            HorizontalDivider(Modifier.padding(vertical = 8.dp))
            Text(tr("Зміна PIN", "Change PIN"), style = MaterialTheme.typography.titleMedium)
            Field(tr("Старий PIN", "Old PIN"), oldPin, { oldPin = it.filter { c -> c in '0'..'9' }.take(6) }, secret = true, numeric = true)
            Field(tr("Поточний ключ", "Current key"), pinKey, { pinKey = it }, secret = true,
                help = tr("Підтвердіть ключ: нотатки лишаться недоторканими, зміниться лише захист.",
                    "Confirm the key: notes stay untouched, only the protection changes."))
            Field(tr("Новий PIN (4–6 цифр)", "New PIN (4–6 digits)"), newPin, { newPin = it.filter { c -> c in '0'..'9' }.take(6) }, secret = true, numeric = true)
            pmsg?.let { Text(it) }
            Button(enabled = !pbusy, modifier = Modifier.fillMaxWidth(), onClick = {
                val t = tooMany()
                if (t != null) pmsg = t
                else if (newPin.length !in 4..6) pmsg = tr("Новий PIN має містити 4–6 цифр.", "New PIN must have 4–6 digits.")
                else scope.launch {
                    pbusy = true
                    val ok = Auth.changePin(oldPin, pinKey, newPin)
                    pbusy = false
                    if (ok) {
                        Auth.keyLock.reset()
                        pmsg = tr("PIN змінено. Біометрію вимкнено — увімкніть знову за потреби.", "PIN changed. Biometrics turned off — enable again if needed.")
                        oldPin = ""; pinKey = ""; newPin = ""; bio = false
                    } else pmsg = wrongKey()
                }
            }) { Text(if (pbusy) tr("Зачекайте…", "Please wait…") else tr("Змінити PIN", "Change PIN")) }

            HorizontalDivider(Modifier.padding(vertical = 8.dp))
            OutlinedButton(onClick = { App.screen = Screen.Help }, modifier = Modifier.fillMaxWidth()) {
                Text(tr("Довідка: як працює шифрування", "Help: how encryption works"))
            }
        }
    }
}

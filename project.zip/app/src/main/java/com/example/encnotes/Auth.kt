@file:OptIn(ExperimentalMaterial3Api::class, ExperimentalFoundationApi::class)

package com.example.encnotes

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.fragment.app.FragmentActivity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@Composable
fun OnboardingScreen() {
    val scope = rememberCoroutineScope()
    val pager = rememberPagerState(pageCount = { 4 })
    val pages = listOf(
        tr("Що це", "What is this") to tr(
            "Офлайн-блокнот для паролів, кодів і конфіденційних нотаток. Усе зберігається лише на вашому телефоні й шифрується. Інтернет не використовується.",
            "An offline notebook for passwords, codes and private notes. Everything stays on your phone, encrypted. No internet is used."
        ),
        tr("Як задавати PIN і ключ", "How to set PIN and key") to tr(
            "PIN (4–6 цифр) відкриває застосунок. \"Головний ключ\" — будь-яке ціле число (наприклад, 4 або 100): без нього нотатки не прочитати.",
            "The PIN (4–6 digits) opens the app. The \"master key\" is any whole number (e.g. 4 or 100): notes cannot be read without it."
        ),
        tr("Що буде, якщо забути ключ", "If you forget the key") to tr(
            "Відновити PIN або ключ неможливо — нікому, навіть авторам. Нотатки назавжди залишаться зашифрованими. Запам'ятайте їх!",
            "PIN or key cannot be recovered — by anyone. The notes will stay encrypted forever. Remember them!"
        ),
        tr("Як перенести нотатки", "How to move notes") to tr(
            "Меню → Експорт дасть шифрований текст. Скопіюйте його, а в іншому екземплярі застосунку: Меню → Імпорт і введіть той самий ключ.",
            "Menu → Export gives encrypted text. Copy it, then in another copy of the app: Menu → Import and enter the same key."
        )
    )
    Scaffold { pad ->
        Column(Modifier.padding(pad).fillMaxSize()) {
            HorizontalPager(pager, Modifier.weight(1f)) { i ->
                Column(
                    Modifier.fillMaxSize().padding(32.dp),
                    verticalArrangement = Arrangement.Center,
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(pages[i].first, style = MaterialTheme.typography.headlineMedium, textAlign = TextAlign.Center)
                    Spacer(Modifier.height(16.dp))
                    Text(pages[i].second, style = MaterialTheme.typography.bodyLarge, textAlign = TextAlign.Center)
                }
            }
            Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                TextButton(onClick = {
                    App.lang = if (App.lang == "uk") "en" else "uk"
                    Store.prefs.edit().putString("lang", App.lang).apply()
                }) { Text(if (App.lang == "uk") "English" else "Українська") }
                Spacer(Modifier.weight(1f))
                Text("${pager.currentPage + 1}/4")
                Spacer(Modifier.width(16.dp))
                Button(onClick = {
                    if (pager.currentPage < 3) scope.launch { pager.animateScrollToPage(pager.currentPage + 1) }
                    else App.screen = Screen.Setup
                }) { Text(if (pager.currentPage < 3) tr("Далі", "Next") else tr("Почати", "Start")) }
            }
        }
    }
}

@Composable
fun SetupScreen() {
    val scope = rememberCoroutineScope()
    var pin by remember { mutableStateOf("") }
    var pin2 by remember { mutableStateOf("") }
    var key by remember { mutableStateOf("") }
    var err by remember { mutableStateOf<String?>(null) }
    var busy by remember { mutableStateOf(false) }
    var warn by remember { mutableStateOf(false) }
    Scaffold { pad ->
        Column(
            Modifier.padding(pad).padding(24.dp).verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text(tr("Створіть PIN і ключ", "Create PIN and key"), style = MaterialTheme.typography.headlineSmall)
            Field(tr("PIN (4–6 цифр)", "PIN (4–6 digits)"), pin, { pin = it.filter(Char::isDigit).take(6) }, secret = true, numeric = true,
                help = tr("PIN відкриває застосунок. Лише цифри, від 4 до 6.", "The PIN opens the app. Digits only, 4 to 6."))
            Field(tr("Повторіть PIN", "Repeat PIN"), pin2, { pin2 = it.filter(Char::isDigit).take(6) }, secret = true, numeric = true)
            Field(tr("Головний ключ (ціле число)", "Master key (whole number)"), key, { key = it.filter(Char::isDigit).take(18) }, secret = true, numeric = true,
                help = tr("Будь-яке ціле число, наприклад 4 або 100. Без нього справжній текст нотаток не показується.",
                    "Any whole number, e.g. 4 or 100. Without it the real text of notes is not shown."))
            err?.let { Text(it, color = MaterialTheme.colorScheme.error) }
            Button(enabled = !busy, modifier = Modifier.fillMaxWidth(), onClick = {
                val k = Auth.parseKey(key)
                err = when {
                    pin.length !in 4..6 -> tr("PIN має містити від 4 до 6 цифр.", "PIN must have 4 to 6 digits.")
                    pin != pin2 -> tr("PIN не збігається. Спробуйте ще раз.", "PINs do not match. Try again.")
                    k == null -> tr("Введіть ключ — ціле число.", "Enter the key — a whole number.")
                    else -> null
                }
                if (err == null && k != null) scope.launch {
                    busy = true
                    val ctx = withContext(Dispatchers.Default) { Auth.setup(pin, k) }
                    busy = false
                    App.pin = pin; App.keyCtx = ctx; App.touch()
                    warn = true
                }
            }) { Text(if (busy) "…" else tr("Створити", "Create")) }
        }
    }
    if (warn) {
        AlertDialog(
            onDismissRequest = {},
            title = { Text(tr("Важливо", "Important")) },
            text = { Text(tr("Якщо ви забудете PIN або ключ, відновити нотатки буде неможливо.",
                "If you forget the PIN or key, the notes cannot be recovered.")) },
            confirmButton = { Button(onClick = { warn = false; App.screen = Screen.Notes }) { Text(tr("Я розумію", "I understand")) } }
        )
    }
}

@Composable
fun LoginScreen(act: FragmentActivity) {
    val scope = rememberCoroutineScope()
    var pin by remember { mutableStateOf("") }
    var err by remember { mutableStateOf<String?>(null) }
    var ver by remember { mutableIntStateOf(0) }
    var busy by remember { mutableStateOf(false) }
    val rem = rememberRemaining(Auth.pinLock, ver)

    fun attempt(p: String) {
        if (Auth.pinLock.remainingMs() > 0) return
        scope.launch {
            busy = true
            val ok = withContext(Dispatchers.Default) { Auth.checkPin(p) }
            busy = false
            if (ok) {
                Auth.pinLock.reset()
                App.pin = p; App.keyCtx = null; App.touch()
                App.screen = Screen.Notes
            } else {
                val left = Auth.pinLock.fail()
                ver++
                pin = ""
                err = if (left > 0) tr("Невірний PIN. Залишилось спроб: $left", "Wrong PIN. Attempts left: $left") else null
            }
        }
    }
    LaunchedEffect(Unit) { if (Bio.enabled && rem <= 0) Bio.login(act) { attempt(it) } }

    Scaffold { pad ->
        Column(
            Modifier.padding(pad).fillMaxSize().padding(32.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(tr("Шифрований блокнот", "Encrypted Notebook"), style = MaterialTheme.typography.headlineMedium)
            Spacer(Modifier.height(24.dp))
            if (rem > 0) {
                Text(tr("Забагато спроб. Спробуйте через ${fmt(rem)}", "Too many attempts. Try again in ${fmt(rem)}"),
                    color = MaterialTheme.colorScheme.error, textAlign = TextAlign.Center)
            } else {
                Field(tr("PIN", "PIN"), pin, { pin = it.filter(Char::isDigit).take(6) }, secret = true, numeric = true)
                err?.let { Text(it, color = MaterialTheme.colorScheme.error) }
                Spacer(Modifier.height(12.dp))
                Button(enabled = !busy && pin.length >= 4, modifier = Modifier.fillMaxWidth(), onClick = { attempt(pin) }) {
                    Text(if (busy) "…" else tr("Увійти", "Unlock"))
                }
                if (Bio.enabled) {
                    TextButton(onClick = { Bio.login(act) { attempt(it) } }) { Text(tr("Відбиток / обличчя", "Fingerprint / face")) }
                }
            }
        }
    }
}

@Composable
fun HelpScreen() {
    BackHandler { App.screen = Screen.Settings }
    Scaffold(topBar = {
        TopAppBar(
            title = { Text(tr("Довідка", "Help")) },
            navigationIcon = { IconButton(onClick = { App.screen = Screen.Settings }) { Icon(Icons.AutoMirrored.Filled.ArrowBack, null) } }
        )
    }) { pad ->
        Text(helpText(), Modifier.padding(pad).padding(16.dp).verticalScroll(rememberScrollState()))
    }
}

@Composable
fun SettingsScreen(act: FragmentActivity) {
    BackHandler { App.screen = Screen.Notes }
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var autolock by remember { mutableIntStateOf(Store.prefs.getInt("autolock", 1)) }
    var mode by remember { mutableStateOf(Store.prefs.getString("mode", "A1") ?: "A1") }
    var bio by remember { mutableStateOf(Bio.enabled) }
    var warnCaesar by remember { mutableStateOf(false) }
    var oldPin by remember { mutableStateOf("") }
    var key by remember { mutableStateOf("") }
    var newPin by remember { mutableStateOf("") }
    var msg by remember { mutableStateOf<String?>(null) }
    var busy by remember { mutableStateOf(false) }

    Scaffold(topBar = {
        TopAppBar(
            title = { Text(tr("Налаштування", "Settings")) },
            navigationIcon = { IconButton(onClick = { App.screen = Screen.Notes }) { Icon(Icons.AutoMirrored.Filled.ArrowBack, null) } }
        )
    }) { pad ->
        Column(
            Modifier.padding(pad).padding(16.dp).verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Text(tr("Мова", "Language"), style = MaterialTheme.typography.titleMedium)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("uk" to "Українська", "en" to "English").forEach { (c, n) ->
                    FilterChip(selected = App.lang == c, onClick = {
                        App.lang = c; Store.prefs.edit().putString("lang", c).apply()
                    }, label = { Text(n) })
                }
            }

            Text(tr("Автоблокування", "Auto-lock"), style = MaterialTheme.typography.titleMedium)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                listOf(1, 5, 15).forEach { m ->
                    FilterChip(selected = autolock == m, onClick = {
                        autolock = m; Store.prefs.edit().putInt("autolock", m).apply()
                    }, label = { Text(tr("$m хв", "$m min")) })
                }
                Help(tr("Через скільки хвилин без дій застосунок заблокується і знову попросить PIN.",
                    "After how many idle minutes the app locks and asks for the PIN again."))
            }

            if (Bio.available(ctx)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(tr("Вхід за відбитком / обличчям", "Fingerprint / face unlock"), Modifier.weight(1f))
                    Switch(checked = bio, onCheckedChange = { on ->
                        if (on) {
                            val p = App.pin
                            if (p != null) Bio.enable(act, p) { ok -> bio = ok }
                        } else { Bio.disable(); bio = false }
                    })
                }
            }

            Text(tr("Режим шифрування", "Encryption mode"), style = MaterialTheme.typography.titleMedium)
            Row(Modifier.fillMaxWidth().clickable { mode = "A1"; Store.prefs.edit().putString("mode", "A1").apply() },
                verticalAlignment = Alignment.CenterVertically) {
                RadioButton(selected = mode == "A1", onClick = { mode = "A1"; Store.prefs.edit().putString("mode", "A1").apply() })
                Text(tr("Надійний (рекомендовано) — AES-256", "Reliable (recommended) — AES-256"), Modifier.weight(1f))
                Help(tr("Сучасне сильне шифрування. Захищає, навіть якщо хтось отримає файл бази даних.",
                    "Modern strong encryption. Protects even if someone gets the database file."))
            }
            Row(Modifier.fillMaxWidth().clickable { warnCaesar = true }, verticalAlignment = Alignment.CenterVertically) {
                RadioButton(selected = mode == "C1", onClick = { warnCaesar = true })
                Text(tr("Простий зсув (Цезар)", "Simple shift (Caesar)"), Modifier.weight(1f))
                Help(tr("Просте перемішування символів. НЕ захищає від серйозного злому. Лише для неважливих нотаток.",
                    "Simple character shuffling. Does NOT protect against serious attacks. Only for unimportant notes."))
            }
            Text(tr("Режим діє для нових і відредагованих нотаток.", "The mode applies to new and edited notes."),
                style = MaterialTheme.typography.bodySmall)

            HorizontalDivider(Modifier.padding(vertical = 8.dp))
            Text(tr("Зміна PIN", "Change PIN"), style = MaterialTheme.typography.titleMedium)
            Field(tr("Старий PIN", "Old PIN"), oldPin, { oldPin = it.filter(Char::isDigit).take(6) }, secret = true, numeric = true)
            Field(tr("Головний ключ", "Master key"), key, { key = it.filter(Char::isDigit).take(18) }, secret = true, numeric = true,
                help = tr("Підтвердіть поточний ключ — нотатки буде перешифровано під новий PIN.",
                    "Confirm the current key — notes will be re-encrypted for the new PIN."))
            Field(tr("Новий PIN (4–6 цифр)", "New PIN (4–6 digits)"), newPin, { newPin = it.filter(Char::isDigit).take(6) }, secret = true, numeric = true)
            msg?.let { Text(it) }
            Button(enabled = !busy, onClick = {
                if (newPin.length !in 4..6) {
                    msg = tr("Новий PIN має містити 4–6 цифр.", "New PIN must have 4–6 digits.")
                } else scope.launch {
                    busy = true
                    val ok = Auth.changePin(oldPin, key, newPin)
                    busy = false
                    msg = if (ok) tr("PIN змінено. Біометрію вимкнено — увімкніть знову за потреби.",
                        "PIN changed. Biometrics turned off — enable again if needed.")
                    else tr("Невірний старий PIN або ключ.", "Wrong old PIN or key.")
                    if (ok) { oldPin = ""; key = ""; newPin = ""; bio = false }
                }
            }) { Text(if (busy) tr("Зачекайте…", "Please wait…") else tr("Змінити PIN", "Change PIN")) }

            HorizontalDivider(Modifier.padding(vertical = 8.dp))
            OutlinedButton(onClick = { App.screen = Screen.Help }, modifier = Modifier.fillMaxWidth()) {
                Text(tr("Довідка: як працює шифрування", "Help: how encryption works"))
            }
        }
    }
    if (warnCaesar) {
        AlertDialog(
            onDismissRequest = { warnCaesar = false },
            title = { Text(tr("Увага", "Warning")) },
            text = { Text(tr("Режим \"Простий зсув\" НЕ захищає від серйозного злому. Не зберігайте в ньому важливі паролі.",
                "\"Simple shift\" mode does NOT protect against serious attacks. Do not store important passwords with it.")) },
            confirmButton = { TextButton(onClick = {
                mode = "C1"; Store.prefs.edit().putString("mode", "C1").apply(); warnCaesar = false
            }) { Text(tr("Все одно увімкнути", "Enable anyway")) } },
            dismissButton = { TextButton(onClick = { warnCaesar = false }) { Text(tr("Скасувати", "Cancel")) } }
        )
    }
}

package com.example.encnotes

import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.math.BigInteger
import java.security.KeyFactory
import java.security.KeyPair
import java.security.KeyPairGenerator
import java.security.PrivateKey
import java.security.PublicKey
import java.security.SecureRandom
import java.security.spec.PKCS8EncodedKeySpec
import java.security.spec.X509EncodedKeySpec
import javax.crypto.Cipher
import javax.crypto.Mac
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.PBEKeySpec
import javax.crypto.spec.SecretKeySpec

fun b64(b: ByteArray): String = Base64.encodeToString(b, Base64.NO_WRAP)
fun b64d(s: String): ByteArray = Base64.decode(s, Base64.NO_WRAP)

object Kdf {
    const val ITER = 210_000
    /** Стандартний PBKDF2-HMAC-SHA256 (один блок 32 байти), але через нативний Mac — значно швидше. */
    fun derive(secret: String, salt: ByteArray): ByteArray {
        val mac = Mac.getInstance("HmacSHA256")
        mac.init(SecretKeySpec(secret.toByteArray(Charsets.UTF_8), "HmacSHA256"))
        mac.update(salt)
        mac.update(byteArrayOf(0, 0, 0, 1))
        var u = mac.doFinal()
        val t = u.copyOf()
        for (i in 1 until ITER) {
            u = mac.doFinal(u)
            for (j in t.indices) t[j] = (t[j].toInt() xor u[j].toInt()).toByte()
        }
        return t
    }
    fun random(n: Int): ByteArray = ByteArray(n).also { SecureRandom().nextBytes(it) }
}

/** aes — 256-бітний ключ з PBKDF2(PIN + ключ); shift — (ключ mod 31) для режиму зсуву. */
class KeyCtx(val aes: ByteArray, val shift: Int)

/** Інтерфейс методу шифрування: щоб додати новий метод — реалізуйте його й додайте в Methods.all */
interface CipherMethod {
    val id: String
    fun encrypt(plain: ByteArray, k: KeyCtx): ByteArray
    fun decrypt(data: ByteArray, k: KeyCtx): ByteArray
}

object AesGcm : CipherMethod {
    override val id = "A1"
    override fun encrypt(plain: ByteArray, k: KeyCtx): ByteArray {
        val iv = Kdf.random(12)
        val c = Cipher.getInstance("AES/GCM/NoPadding")
        c.init(Cipher.ENCRYPT_MODE, SecretKeySpec(k.aes, "AES"), GCMParameterSpec(128, iv))
        return iv + c.doFinal(plain)
    }
    override fun decrypt(data: ByteArray, k: KeyCtx): ByteArray {
        val c = Cipher.getInstance("AES/GCM/NoPadding")
        c.init(Cipher.DECRYPT_MODE, SecretKeySpec(k.aes, "AES"), GCMParameterSpec(128, data.copyOfRange(0, 12)))
        return c.doFinal(data, 12, data.size - 12)
    }
}

/** Простий зсув байтів (Цезар) — НЕ захищає від серйозного злому. */
object Caesar : CipherMethod {
    override val id = "C1"
    override fun encrypt(plain: ByteArray, k: KeyCtx) = ByteArray(plain.size) { (plain[it] + k.shift).toByte() }
    override fun decrypt(data: ByteArray, k: KeyCtx) = ByteArray(data.size) { (data[it] - k.shift).toByte() }
}

object Methods {
    val all: List<CipherMethod> = listOf(AesGcm, Caesar)
    fun get(id: String): CipherMethod = all.first { it.id == id }
    fun idOf(blob: String) = blob.substringBefore(':')
    fun enc(id: String, s: String, k: KeyCtx): String = id + ":" + b64(get(id).encrypt(s.toByteArray(Charsets.UTF_8), k))
    fun dec(blob: String, k: KeyCtx): String =
        String(get(idOf(blob)).decrypt(b64d(blob.substringAfter(':')), k), Charsets.UTF_8)
    fun safeDec(blob: String, k: KeyCtx): String = try { dec(blob, k) } catch (e: Exception) { "⚠" }
    fun reenc(blob: String, old: KeyCtx, new: KeyCtx): String = enc(idOf(blob), dec(blob, old), new)
}

data class PlainNote(val title: String, val body: String, val password: String, val tags: String) {
    /** Старе окреме поле "пароль" зливається в текст нотатки. */
    fun merged(): PlainNote =
        if (password.isBlank()) this
        else copy(body = body + (if (body.isBlank()) "" else "\n") + "Пароль: " + password, password = "")
}

/** Експорт/імпорт: шифрується AES-256-GCM ключем, виведеним лише з "головного ключа" + випадкової солі. */
object Transfer {
    fun export(list: List<PlainNote>, key: String): String {
        val arr = JSONArray()
        list.forEach {
            arr.put(JSONObject().put("t", it.title).put("b", it.body).put("p", it.password).put("g", it.tags))
        }
        val salt = Kdf.random(16)
        val ctx = KeyCtx(Kdf.derive("export:$key", salt), 0)
        return "ENB1:" + b64(salt) + ":" + Methods.enc("A1", arr.toString(), ctx)
    }

    fun import(text: String, key: String): List<PlainNote>? = try {
        val parts = text.trim().split(":", limit = 3)
        require(parts.size == 3 && parts[0] == "ENB1")
        val ctx = KeyCtx(Kdf.derive("export:$key", b64d(parts[1])), 0)
        val arr = JSONArray(Methods.dec(parts[2], ctx))
        List(arr.length()) {
            val o = arr.getJSONObject(it)
            PlainNote(o.getString("t"), o.getString("b"), o.getString("p"), o.getString("g"))
        }
    } catch (e: Exception) {
        null
    }
}

/** Асиметричне "загортання" ключа нотатки: нову нотатку можна зашифрувати без ключа користувача (лише публічним ключем). */
object Rsa {
    private const val ALG = "RSA/ECB/OAEPWithSHA-1AndMGF1Padding"
    fun generate(): KeyPair = KeyPairGenerator.getInstance("RSA").apply { initialize(2048) }.generateKeyPair()
    fun pubFrom(b: ByteArray): PublicKey = KeyFactory.getInstance("RSA").generatePublic(X509EncodedKeySpec(b))
    fun privFrom(b: ByteArray): PrivateKey = KeyFactory.getInstance("RSA").generatePrivate(PKCS8EncodedKeySpec(b))
    fun wrap(pub: PublicKey, dek: ByteArray): ByteArray {
        val c = Cipher.getInstance(ALG)
        c.init(Cipher.ENCRYPT_MODE, pub)
        return c.doFinal(dek)
    }
    fun unwrap(priv: PrivateKey, w: ByteArray): ByteArray {
        val c = Cipher.getInstance(ALG)
        c.init(Cipher.DECRYPT_MODE, priv)
        return c.doFinal(w)
    }
}

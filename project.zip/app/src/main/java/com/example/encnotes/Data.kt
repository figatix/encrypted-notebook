package com.example.encnotes

import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.SharedPreferences
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.PersistableBundle
import android.os.SystemClock
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.core.content.ContextCompat
import androidx.fragment.app.FragmentActivity
import androidx.room.*
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.math.BigInteger
import java.security.KeyStore
import java.security.MessageDigest
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

// ---------- Room: у БД лише шифровані поля ----------
@Entity(tableName = "notes")
data class NoteEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val body: String,
    val password: String,
    val tags: String,
    val updated: Long
)

@Dao
interface NoteDao {
    @Query("SELECT * FROM notes ORDER BY updated DESC") suspend fun all(): List<NoteEntity>
    @Query("SELECT * FROM notes WHERE id = :id") suspend fun get(id: Long): NoteEntity?
    @Insert suspend fun insert(n: NoteEntity): Long
    @Update suspend fun update(n: NoteEntity)
    @Query("DELETE FROM notes WHERE id = :id") suspend fun delete(id: Long)
}

@Database(entities = [NoteEntity::class], version = 1, exportSchema = false)
abstract class Db : RoomDatabase() {
    abstract fun dao(): NoteDao
}

// ---------- Сховища ----------
object Store {
    private var inited = false
    lateinit var db: Db
    lateinit var prefs: SharedPreferences

    fun init(ctx: Context) {
        if (inited) return
        inited = true
        val mk = MasterKey.Builder(ctx).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build()
        prefs = EncryptedSharedPreferences.create(
            ctx, "secure_prefs", mk,
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
        )
        db = Room.databaseBuilder(ctx, Db::class.java, "notes.db").build()
    }
}

sealed interface Screen {
    object Onboarding : Screen
    object Setup : Screen
    object Login : Screen
    object Notes : Screen
    object Settings : Screen
    object Help : Screen
    data class Editor(val id: Long) : Screen
}

/** Стан сесії — лише в пам'яті. */
object App {
    var lang by mutableStateOf("uk")
    var screen: Screen by mutableStateOf<Screen>(Screen.Login)
    var pin: String? = null
    var keyCtx by mutableStateOf<KeyCtx?>(null)
    var keyNum: BigInteger? = null
    private var lastActive = SystemClock.elapsedRealtime()

    fun touch() { lastActive = SystemClock.elapsedRealtime() }

    fun lock() {
        pin = null; keyCtx = null; keyNum = null
        if (Auth.isSetup()) screen = Screen.Login
    }

    fun checkAutoLock() {
        if (pin == null) return
        val mins = Store.prefs.getInt("autolock", 1)
        if (SystemClock.elapsedRealtime() - lastActive > mins * 60_000L) lock()
    }
}

class Lockout(private val name: String) {
    private val p get() = Store.prefs
    fun remainingMs(): Long = maxOf(0L, p.getLong("${name}_until", 0L) - System.currentTimeMillis())
    fun reset() { p.edit().putInt("${name}_fails", 0).putLong("${name}_until", 0L).apply() }
    /** Повертає кількість спроб, що залишилась (0 = заблоковано на 10 хв). */
    fun fail(): Int {
        val n = p.getInt("${name}_fails", 0) + 1
        return if (n >= 5) {
            p.edit().putInt("${name}_fails", 0).putLong("${name}_until", System.currentTimeMillis() + 10 * 60_000L).apply()
            0
        } else {
            p.edit().putInt("${name}_fails", n).apply()
            5 - n
        }
    }
}

object Auth {
    val pinLock = Lockout("pin")
    val keyLock = Lockout("key")
    private const val CHECK = "ENB-OK"
    private val p get() = Store.prefs

    fun isSetup() = p.contains("pin_hash")
    fun parseKey(s: String): BigInteger? =
        s.trim().takeIf { it.isNotEmpty() && it.length <= 18 && it.all { c -> c in '0'..'9' } }?.let { BigInteger(it) }

    /** Нормалізація: 100 mod 31 = 7 — для режиму зсуву. Користувач вводить 100. */
    private fun shift(k: BigInteger) = k.mod(BigInteger.valueOf(31)).toInt()
    private fun derive(pin: String, k: BigInteger, salt: ByteArray) = KeyCtx(Kdf.derive("$pin:$k", salt), shift(k))

    fun checkPin(pin: String): Boolean {
        val h = Kdf.derive(pin, b64d(p.getString("pin_salt", "")!!))
        return MessageDigest.isEqual(h, b64d(p.getString("pin_hash", "")!!))
    }

    fun setup(pin: String, k: BigInteger): KeyCtx {
        val ps = Kdf.random(16); val ks = Kdf.random(16)
        val ctx = derive(pin, k, ks)
        p.edit().putString("pin_salt", b64(ps)).putString("pin_hash", b64(Kdf.derive(pin, ps)))
            .putString("kdf_salt", b64(ks)).putString("check", Methods.enc("A1", CHECK, ctx)).commit()
        App.keyNum = k
        return ctx
    }

    /** null — ключ невірний */
    fun unlock(pin: String, keyStr: String): KeyCtx? {
        val k = parseKey(keyStr) ?: return null
        val ctx = derive(pin, k, b64d(p.getString("kdf_salt", "")!!))
        val ok = try { Methods.dec(p.getString("check", "")!!, ctx) == CHECK } catch (e: Exception) { false }
        if (!ok) return null
        App.keyNum = k
        return ctx
    }

    suspend fun changePin(oldPin: String, keyStr: String, newPin: String): Boolean = withContext(Dispatchers.Default) {
        try {
            if (!checkPin(oldPin)) return@withContext false
            val old = unlock(oldPin, keyStr) ?: return@withContext false
            val k = App.keyNum!!
            val ks = Kdf.random(16); val ps = Kdf.random(16)
            val nw = derive(newPin, k, ks)
            val notes = Store.db.dao().all().map {
                it.copy(
                    title = Methods.reenc(it.title, old, nw), body = Methods.reenc(it.body, old, nw),
                    password = Methods.reenc(it.password, old, nw), tags = Methods.reenc(it.tags, old, nw)
                )
            }
            Store.db.withTransaction { notes.forEach { Store.db.dao().update(it) } }
            p.edit().putString("pin_salt", b64(ps)).putString("pin_hash", b64(Kdf.derive(newPin, ps)))
                .putString("kdf_salt", b64(ks)).putString("check", Methods.enc("A1", CHECK, nw)).commit()
            Bio.disable()
            App.pin = newPin
            App.keyCtx = nw
            true
        } catch (e: Exception) {
            false
        }
    }

    suspend fun save(id: Long, n: PlainNote) {
        val c = App.keyCtx ?: return
        val m = p.getString("mode", "A1")!!
        val e = NoteEntity(
            id, Methods.enc(m, n.title, c), Methods.enc(m, n.body, c),
            Methods.enc(m, n.password, c), Methods.enc(m, n.tags, c), System.currentTimeMillis()
        )
        if (id == 0L) Store.db.dao().insert(e) else Store.db.dao().update(e)
    }

    suspend fun plainAll(): List<PlainNote> {
        val c = App.keyCtx ?: return emptyList()
        return Store.db.dao().all().map {
            PlainNote(Methods.safeDec(it.title, c), Methods.safeDec(it.body, c), Methods.safeDec(it.password, c), Methods.safeDec(it.tags, c))
        }
    }
}

// ---------- Буфер обміну з автоочищенням ----------
object Clip {
    private val h = Handler(Looper.getMainLooper())
    private var r: Runnable? = null

    fun copySecret(ctx: Context, text: String) {
        val cm = ctx.applicationContext.getSystemService(ClipboardManager::class.java)
        val clip = ClipData.newPlainText("secret", text)
        if (Build.VERSION.SDK_INT >= 33) {
            clip.description.extras = PersistableBundle().apply { putBoolean("android.content.extra.IS_SENSITIVE", true) }
        }
        cm.setPrimaryClip(clip)
        r?.let { h.removeCallbacks(it) }
        val run = Runnable {
            if (Build.VERSION.SDK_INT >= 28) cm.clearPrimaryClip() else cm.setPrimaryClip(ClipData.newPlainText("", ""))
        }
        r = run
        h.postDelayed(run, 30_000L)
    }

    fun copyPlain(ctx: Context, text: String) {
        ctx.applicationContext.getSystemService(ClipboardManager::class.java)
            .setPrimaryClip(ClipData.newPlainText("export", text))
    }
}

// ---------- Біометрія: PIN шифрується ключем Keystore, що відкривається лише відбитком/обличчям ----------
object Bio {
    private const val ALIAS = "enb_bio_key"
    val enabled: Boolean get() = Store.prefs.contains("bio_ct")

    fun available(ctx: Context) = BiometricManager.from(ctx)
        .canAuthenticate(BiometricManager.Authenticators.BIOMETRIC_STRONG) == BiometricManager.BIOMETRIC_SUCCESS

    private fun key(): SecretKey {
        val ks = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        (ks.getKey(ALIAS, null) as? SecretKey)?.let { return it }
        val b = KeyGenParameterSpec.Builder(ALIAS, KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
            .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
            .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
            .setKeySize(256)
            .setUserAuthenticationRequired(true)
            .setInvalidatedByBiometricEnrollment(true)
        if (Build.VERSION.SDK_INT >= 30) {
            b.setUserAuthenticationParameters(0, KeyProperties.AUTH_BIOMETRIC_STRONG)
        } else {
            @Suppress("DEPRECATION")
            b.setUserAuthenticationValidityDurationSeconds(-1)
        }
        return KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore").apply { init(b.build()) }.generateKey()
    }

    private fun prompt(act: FragmentActivity, cipher: Cipher, onOk: (Cipher) -> Unit) {
        val p = BiometricPrompt(act, ContextCompat.getMainExecutor(act), object : BiometricPrompt.AuthenticationCallback() {
            override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                result.cryptoObject?.cipher?.let(onOk)
            }
        })
        val info = BiometricPrompt.PromptInfo.Builder()
            .setTitle(tr("Вхід у блокнот", "Unlock notebook"))
            .setNegativeButtonText(tr("Скасувати", "Cancel"))
            .setAllowedAuthenticators(BiometricManager.Authenticators.BIOMETRIC_STRONG)
            .build()
        p.authenticate(info, BiometricPrompt.CryptoObject(cipher))
    }

    fun enable(act: FragmentActivity, pin: String, done: (Boolean) -> Unit) {
        try {
            val c = Cipher.getInstance("AES/GCM/NoPadding")
            c.init(Cipher.ENCRYPT_MODE, key())
            prompt(act, c) { ci ->
                try {
                    val ct = ci.doFinal(pin.toByteArray(Charsets.UTF_8))
                    Store.prefs.edit().putString("bio_ct", b64(ct)).putString("bio_iv", b64(ci.iv)).commit()
                    done(true)
                } catch (e: Exception) { done(false) }
            }
        } catch (e: Exception) { done(false) }
    }

    fun login(act: FragmentActivity, onPin: (String) -> Unit) {
        try {
            val p = Store.prefs
            val iv = b64d(p.getString("bio_iv", "")!!)
            val ct = b64d(p.getString("bio_ct", "")!!)
            val c = Cipher.getInstance("AES/GCM/NoPadding")
            c.init(Cipher.DECRYPT_MODE, key(), GCMParameterSpec(128, iv))
            prompt(act, c) { ci ->
                try { onPin(String(ci.doFinal(ct), Charsets.UTF_8)) } catch (e: Exception) { disable() }
            }
        } catch (e: Exception) {
            disable() // ключ анульовано (напр., додано новий відбиток)
        }
    }

    fun disable() {
        Store.prefs.edit().remove("bio_ct").remove("bio_iv").commit()
        try { KeyStore.getInstance("AndroidKeyStore").apply { load(null) }.deleteEntry(ALIAS) } catch (e: Exception) {}
    }
}

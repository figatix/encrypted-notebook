package com.example.encnotes

import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.SharedPreferences
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.PersistableBundle
import android.os.SystemClock
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.core.content.ContextCompat
import androidx.fragment.app.FragmentActivity
import androidx.room.*
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.math.BigInteger
import java.security.PrivateKey
import org.json.JSONArray
import org.json.JSONObject
import java.security.KeyStore
import java.security.MessageDigest
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

// ---------- Room: у БД лише шифровані поля ----------
@Entity(tableName = "notes")
data class NoteEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val body: String,
    @ColumnInfo(name = "password") val wrapped: String,
    val tags: String,
    val updated: Long
)

@Dao
interface NoteDao {
    @Query("SELECT * FROM notes ORDER BY updated DESC") suspend fun all(): List<NoteEntity>
    @Query("SELECT * FROM notes WHERE id = :id") suspend fun get(id: Long): NoteEntity?
    @Insert suspend fun insert(n: NoteEntity): Long
    @Update suspend fun update(n: NoteEntity)
    @Query("DELETE FROM notes WHERE id = :id") suspend fun delete(id: Long)
}

@Database(entities = [NoteEntity::class], version = 1, exportSchema = false)
abstract class Db : RoomDatabase() {
    abstract fun dao(): NoteDao
}

// ---------- Сховища ----------
object Store {
    private var inited = false
    lateinit var db: Db
    lateinit var appCtx: Context
    lateinit var prefs: SharedPreferences

    fun init(ctx: Context) {
        if (inited) return
        inited = true
        appCtx = ctx
        val mk = MasterKey.Builder(ctx).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build()
        prefs = EncryptedSharedPreferences.create(
            ctx, "secure_prefs", mk,
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
        )
        db = Room.databaseBuilder(ctx, Db::class.java, "notes.db").build()
    }
}

sealed interface Screen {
    object Onboarding : Screen
    object Setup : Screen
    object Login : Screen
    object Migrate : Screen
    object Notes : Screen
    object Settings : Screen
    object Help : Screen
    data class Editor(val id: Long) : Screen
}

/** Секрет сесії після введення ключа: приватний RSA-ключ (надійний режим) або зсув (Цезар). */
class Vault(val priv: PrivateKey?, val shift: Int, val keyText: String)

/** Стан сесії — лише в пам'яті. */
object App {
    var lang by mutableStateOf("uk")
    var screen: Screen by mutableStateOf<Screen>(Screen.Login)
    var pin: String? = null
    var vault by mutableStateOf<Vault?>(null)
    var query: String = ""
    private var stoppedAt = 0L

    fun onStop() { stoppedAt = SystemClock.elapsedRealtime() }

    fun lock() {
        pin = null; vault = null; query = ""
        if (Auth.isSetup()) screen = Screen.Login
    }

    /** Блокуємо лише якщо застосунок був поза екраном довше, ніж задано в налаштуваннях. */
    fun onStart() {
        if (pin == null || stoppedAt == 0L) return
        val mins = Store.prefs.getInt("autolock", 5)
        if (SystemClock.elapsedRealtime() - stoppedAt >= mins * 60_000L) lock()
    }
}

class Lockout(private val name: String) {
    private val p get() = Store.prefs
    fun remainingMs(): Long = maxOf(0L, p.getLong("${name}_until", 0L) - System.currentTimeMillis())
    fun reset() { p.edit().putInt("${name}_fails", 0).putLong("${name}_until", 0L).apply() }
    /** Повертає кількість спроб, що залишилась (0 = заблоковано на 10 хв). */
    fun fail(): Int {
        val n = p.getInt("${name}_fails", 0) + 1
        return if (n >= 5) {
            p.edit().putInt("${name}_fails", 0).putLong("${name}_until", System.currentTimeMillis() + 10 * 60_000L).apply()
            0
        } else {
            p.edit().putInt("${name}_fails", n).apply()
            5 - n
        }
    }
}

object Auth {
    val pinLock = Lockout("pin")
    val keyLock = Lockout("key")
    private const val CHECK = "ENB-OK"
    private val p get() = Store.prefs

    // fmt: 0 — не налаштовано, 1 — старий формат (PIN+ключ разом), 2 — поточний
    fun fmt(): Int = p.getInt("fmt", if (p.contains("check")) 1 else 0)
    fun isSetup() = fmt() == 2
    fun needsMigration() = fmt() == 1
    /** "A2" — надійний (AES-256 + RSA), "C1" — простий зсув (Цезар) */
    fun mode(): String = p.getString("v2_mode", "A2") ?: "A2"

    fun validKey(mode: String, k: String) =
        if (mode == "C1") k.isNotEmpty() && k.length <= 18 && k.all { it in '0'..'9' } else k.isNotEmpty()

    /** Нормалізація для Цезаря: 100 mod 31 = 7. Користувач вводить 100. */
    private fun shiftOf(k: String) = BigInteger(k).mod(BigInteger.valueOf(31)).toInt()
    private fun kek(pin: String, key: String, salt: ByteArray) = KeyCtx(Kdf.derive("$pin:$key", salt), 0)

    fun checkPin(pin: String): Boolean {
        val h = Kdf.derive(pin, b64d(p.getString("v2_pin_salt", "")!!))
        return MessageDigest.isEqual(h, b64d(p.getString("v2_pin_hash", "")!!))
    }

    /** Записує PIN-хеш і "захищений" ключ (приватний RSA під ключем користувача). Ноти не чіпає. */
    private fun writeKeys(pin: String, key: String, mode: String, pub: ByteArray?, priv: ByteArray?, setFmt: Boolean) {
        val ps = Kdf.random(16); val ks = Kdf.random(16)
        val kk = kek(pin, key, ks)
        val e = p.edit()
            .putString("v2_pin_salt", b64(ps)).putString("v2_pin_hash", b64(Kdf.derive(pin, ps)))
            .putString("v2_kdf_salt", b64(ks)).putString("v2_check", Methods.enc("A1", CHECK, kk))
            .putString("v2_mode", mode)
        if (mode == "A2") {
            require(pub != null && priv != null)
            e.putString("v2_pub", b64(pub)).putString("v2_priv", Methods.enc("A1", b64(priv), kk))
        } else {
            e.remove("v2_pub").remove("v2_priv")
        }
        if (setFmt) e.putInt("fmt", 2)
        e.commit()
    }

    fun setup(pin: String, key: String): Vault {
        val kp = Rsa.generate()
        writeKeys(pin, key, "A2", kp.public.encoded, kp.private.encoded, true)
        return Vault(kp.private, 0, key)
    }

    /** Перевірка ключа. null — невірний. */
    fun unlockKey(pin: String, key: String): Vault? {
        val kk = kek(pin, key, b64d(p.getString("v2_kdf_salt", "")!!))
        try {
            if (Methods.dec(p.getString("v2_check", "")!!, kk) != CHECK) return null
        } catch (e: Exception) { return null }
        return try {
            if (mode() == "A2") {
                Vault(Rsa.privFrom(b64d(Methods.dec(p.getString("v2_priv", "")!!, kk))), 0, key)
            } else Vault(null, shiftOf(key), key)
        } catch (e: Exception) { null }
    }

    class Enc(val title: String, val body: String, val tags: String, val wrapped: String)

    private fun encWith(mode: String, n: PlainNote, v: Vault?, pub: ByteArray?): Enc {
        if (mode == "A2") {
            val dek = Kdf.random(32)
            val c = KeyCtx(dek, 0)
            val w = "W2:" + b64(Rsa.wrap(Rsa.pubFrom(pub!!), dek))
            return Enc(Methods.enc("A1", n.title, c), Methods.enc("A1", n.body, c), Methods.enc("A1", n.tags, c), w)
        }
        val c = KeyCtx(ByteArray(0), v!!.shift)
        return Enc(Methods.enc("C1", n.title, c), Methods.enc("C1", n.body, c), Methods.enc("C1", n.tags, c), "C1:")
    }

    fun decrypt(e: NoteEntity, v: Vault, strict: Boolean = false): PlainNote = try {
        val c = if (e.wrapped.startsWith("W2:")) KeyCtx(Rsa.unwrap(v.priv!!, b64d(e.wrapped.substring(3))), 0)
        else KeyCtx(ByteArray(0), v.shift)
        val d = { b: String -> if (strict) Methods.dec(b, c) else Methods.safeDec(b, c) }
        PlainNote(d(e.title), d(e.body), "", d(e.tags))
    } catch (ex: Exception) {
        if (strict) throw ex else PlainNote("⚠", "", "", "")
    }

    /** Нову нотатку в надійному режимі шифруємо лише публічним ключем — без введення ключа. */
    suspend fun save(id: Long, n: PlainNote): Boolean = withContext(Dispatchers.Default) {
        val m = mode()
        if (m == "C1" && App.vault == null) return@withContext false
        val pub = if (m == "A2") b64d(p.getString("v2_pub", "")!!) else null
        val e = encWith(m, n, App.vault, pub)
        val ent = NoteEntity(id, e.title, e.body, e.wrapped, e.tags, System.currentTimeMillis())
        if (id == 0L) Store.db.dao().insert(ent) else Store.db.dao().update(ent)
        true
    }

    suspend fun plainAll(): List<PlainNote> {
        val v = App.vault ?: return emptyList()
        return Store.db.dao().all().map { decrypt(it, v) }
    }

    /** Зміна PIN: нотатки не чіпаємо, лише перезаписуємо захист ключа. */
    suspend fun changePin(oldPin: String, key: String, newPin: String): Boolean = withContext(Dispatchers.Default) {
        try {
            if (!checkPin(oldPin)) return@withContext false
            val v = unlockKey(oldPin, key) ?: return@withContext false
            val pub = p.getString("v2_pub", null)?.let { b64d(it) }
            writeKeys(newPin, key, mode(), pub, v.priv?.encoded, false)
            Bio.disable()
            App.pin = newPin
            App.vault = v
            true
        } catch (e: Exception) { false }
    }

    /** Зміна ключа та/або режиму. Для Цезаря ключ — лише цифри. */
    suspend fun changeKey(curKey: String, newMode: String, newKey: String): Boolean = withContext(Dispatchers.Default) {
        try {
            val pin = App.pin ?: return@withContext false
            val old = unlockKey(pin, curKey) ?: return@withContext false
            if (!validKey(newMode, newKey)) return@withContext false
            val pub = p.getString("v2_pub", null)?.let { b64d(it) }
            if (mode() == "A2" && newMode == "A2") {
                writeKeys(pin, newKey, "A2", pub, old.priv!!.encoded, false)
                App.vault = Vault(old.priv, 0, newKey)
                return@withContext true
            }
            val rows = Store.db.dao().all()
            val plain = rows.map { decrypt(it, old, strict = true) }
            var nPub: ByteArray? = null
            var nPriv: ByteArray? = null
            val nv: Vault
            if (newMode == "A2") {
                val kp = Rsa.generate()
                nPub = kp.public.encoded; nPriv = kp.private.encoded
                nv = Vault(kp.private, 0, newKey)
            } else nv = Vault(null, shiftOf(newKey), newKey)
            val updated = rows.zip(plain).map { (r, n) ->
                val e = encWith(newMode, n, nv, nPub)
                r.copy(title = e.title, body = e.body, wrapped = e.wrapped, tags = e.tags)
            }
            Store.db.withTransaction { updated.forEach { Store.db.dao().update(it) } }
            writeKeys(pin, newKey, newMode, nPub, nPriv, false)
            App.vault = nv
            true
        } catch (e: Exception) { false }
    }

    /** Перехід зі старого формату (PIN+ключ разом) без втрати нотаток. */
    suspend fun migrate(pin: String, keyStr: String): Boolean = withContext(Dispatchers.Default) {
        try {
            val k = keyStr.trim().takeIf { it.isNotEmpty() && it.length <= 18 && it.all { c -> c in '0'..'9' } }
                ?.let { BigInteger(it) } ?: return@withContext false
            val key = k.toString()
            val old = KeyCtx(Kdf.derive("$pin:$k", b64d(p.getString("kdf_salt", "")!!)), shiftOf(key))
            if (Methods.dec(p.getString("check", "")!!, old) != CHECK) return@withContext false
            val rows = Store.db.dao().all()
            val plain = rows.map {
                PlainNote(Methods.dec(it.title, old), Methods.dec(it.body, old), Methods.dec(it.wrapped, old), Methods.dec(it.tags, old)).merged()
            }
            // страховка: зашифровані старі рядки (без відкритого тексту)
            val arr = JSONArray()
            rows.forEach {
                arr.put(JSONObject().put("id", it.id).put("t", it.title).put("b", it.body).put("p", it.wrapped).put("g", it.tags).put("u", it.updated))
            }
            File(Store.appCtx.filesDir, "legacy_backup.json").writeText(arr.toString())

            val mode = if (p.getString("mode", "A1") == "C1") "C1" else "A2"
            var pub: ByteArray? = null
            var priv: ByteArray? = null
            val vault: Vault
            if (mode == "A2") {
                val kp = Rsa.generate()
                pub = kp.public.encoded; priv = kp.private.encoded
                vault = Vault(kp.private, 0, key)
            } else vault = Vault(null, shiftOf(key), key)
            val updated = rows.zip(plain).map { (r, n) ->
                val e = encWith(mode, n, vault, pub)
                r.copy(title = e.title, body = e.body, wrapped = e.wrapped, tags = e.tags)
            }
            writeKeys(pin, key, mode, pub, priv, false)
            Store.db.withTransaction { updated.forEach { Store.db.dao().update(it) } }
            p.edit().putInt("fmt", 2).commit()
            Bio.disable()
            App.pin = pin
            App.vault = vault
            true
        } catch (e: Exception) { false }
    }
}

// ---------- Буфер обміну з автоочищенням ----------
object Clip {
    private val h = Handler(Looper.getMainLooper())
    private var r: Runnable? = null

    fun copySecret(ctx: Context, text: String) {
        val cm = ctx.applicationContext.getSystemService(ClipboardManager::class.java)
        val clip = ClipData.newPlainText("secret", text)
        if (Build.VERSION.SDK_INT >= 33) {
            clip.description.extras = PersistableBundle().apply { putBoolean("android.content.extra.IS_SENSITIVE", true) }
        }
        cm.setPrimaryClip(clip)
        r?.let { h.removeCallbacks(it) }
        val run = Runnable {
            if (Build.VERSION.SDK_INT >= 28) cm.clearPrimaryClip() else cm.setPrimaryClip(ClipData.newPlainText("", ""))
        }
        r = run
        h.postDelayed(run, 30_000L)
    }

    fun copyPlain(ctx: Context, text: String) {
        ctx.applicationContext.getSystemService(ClipboardManager::class.java)
            .setPrimaryClip(ClipData.newPlainText("export", text))
    }
}

// ---------- Біометрія: PIN шифрується ключем Keystore, що відкривається лише відбитком/обличчям ----------
object Bio {
    private const val ALIAS = "enb_bio_key"
    val enabled: Boolean get() = Store.prefs.contains("bio_ct")

    fun available(ctx: Context) = BiometricManager.from(ctx)
        .canAuthenticate(BiometricManager.Authenticators.BIOMETRIC_STRONG) == BiometricManager.BIOMETRIC_SUCCESS

    private fun key(): SecretKey {
        val ks = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        (ks.getKey(ALIAS, null) as? SecretKey)?.let { return it }
        val b = KeyGenParameterSpec.Builder(ALIAS, KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
            .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
            .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
            .setKeySize(256)
            .setUserAuthenticationRequired(true)
            .setInvalidatedByBiometricEnrollment(true)
        if (Build.VERSION.SDK_INT >= 30) {
            b.setUserAuthenticationParameters(0, KeyProperties.AUTH_BIOMETRIC_STRONG)
        } else {
            @Suppress("DEPRECATION")
            b.setUserAuthenticationValidityDurationSeconds(-1)
        }
        return KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore").apply { init(b.build()) }.generateKey()
    }

    private fun prompt(act: FragmentActivity, cipher: Cipher, onOk: (Cipher) -> Unit) {
        val p = BiometricPrompt(act, ContextCompat.getMainExecutor(act), object : BiometricPrompt.AuthenticationCallback() {
            override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                result.cryptoObject?.cipher?.let(onOk)
            }
        })
        val info = BiometricPrompt.PromptInfo.Builder()
            .setTitle(tr("Вхід у блокнот", "Unlock notebook"))
            .setNegativeButtonText(tr("Скасувати", "Cancel"))
            .setAllowedAuthenticators(BiometricManager.Authenticators.BIOMETRIC_STRONG)
            .build()
        p.authenticate(info, BiometricPrompt.CryptoObject(cipher))
    }

    fun enable(act: FragmentActivity, pin: String, done: (Boolean) -> Unit) {
        try {
            val c = Cipher.getInstance("AES/GCM/NoPadding")
            c.init(Cipher.ENCRYPT_MODE, key())
            prompt(act, c) { ci ->
                try {
                    val ct = ci.doFinal(pin.toByteArray(Charsets.UTF_8))
                    Store.prefs.edit().putString("bio_ct", b64(ct)).putString("bio_iv", b64(ci.iv)).commit()
                    done(true)
                } catch (e: Exception) { done(false) }
            }
        } catch (e: Exception) { done(false) }
    }

    fun login(act: FragmentActivity, onPin: (String) -> Unit) {
        try {
            val p = Store.prefs
            val iv = b64d(p.getString("bio_iv", "")!!)
            val ct = b64d(p.getString("bio_ct", "")!!)
            val c = Cipher.getInstance("AES/GCM/NoPadding")
            c.init(Cipher.DECRYPT_MODE, key(), GCMParameterSpec(128, iv))
            prompt(act, c) { ci ->
                try { onPin(String(ci.doFinal(ct), Charsets.UTF_8)) } catch (e: Exception) { disable() }
            }
        } catch (e: Exception) {
            disable() // ключ анульовано (напр., додано новий відбиток)
        }
    }

    fun disable() {
        Store.prefs.edit().remove("bio_ct").remove("bio_iv").commit()
        try { KeyStore.getInstance("AndroidKeyStore").apply { load(null) }.deleteEntry(ALIAS) } catch (e: Exception) {}
    }
}

@file:OptIn(ExperimentalMaterial3Api::class)

package com.example.encnotes

import android.Manifest
import android.app.AlarmManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

// ---------- Кольори карток (зберігаються зашифровано в полі тегів як "🎨N") ----------
val ColorRe = Regex("🎨(\\d)")
fun colorOf(tags: String): Int = ColorRe.find(tags)?.groupValues?.get(1)?.toInt() ?: 0
fun withColor(tags: String, c: Int): String {
    val t = tags.replace(ColorRe, "").trim()
    return if (c == 0) t else "$t 🎨$c".trim()
}

private val Palette = listOf(
    0xFFFFD6D6 to 0xFF4D2A2A, 0xFFFFE8BF to 0xFF4D3A1C, 0xFFD5F0D6 to 0xFF29442C,
    0xFFD2E9F7 to 0xFF1F3C4D, 0xFFE4D8F5 to 0xFF38294D, 0xFFF7D6EA to 0xFF4D2942
)

@Composable
fun noteColor(c: Int): Color? {
    if (c !in 1..6) return null
    val p = Palette[c - 1]
    return Color(if (isSystemInDarkTheme()) p.second else p.first)
}

@Composable
fun ColorDot(c: Int, selected: Boolean, size: Dp = 32.dp, onClick: () -> Unit) {
    val fill = noteColor(c) ?: MaterialTheme.colorScheme.surface
    val line = if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline
    Box(
        Modifier.size(size).clip(CircleShape).background(fill)
            .border(if (selected) 2.dp else 1.dp, line, CircleShape)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) { if (c == 0) Text("∅", color = MaterialTheme.colorScheme.onSurfaceVariant) }
}

@Composable
fun ColorDialog(current: Int, onPick: (Int) -> Unit, onClose: () -> Unit) {
    AlertDialog(
        onDismissRequest = onClose,
        title = { Text(tr("Колір нотатки", "Note color")) },
        text = {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                (0..6).forEach { ColorDot(it, it == current, 30.dp) { onPick(it) } }
            }
        },
        confirmButton = {},
        dismissButton = { TextButton(onClick = onClose) { Text(tr("Закрити", "Close")) } }
    )
}

fun sortLabel(s: Int): String = when (s) {
    1 -> tr("Старі спочатку", "Oldest first")
    2 -> tr("Назва А→Я", "Title A→Z")
    3 -> tr("Назва Я→А", "Title Z→A")
    else -> tr("Нові спочатку", "Newest first")
}

// ---------- Нагадування: без мережі й фонових сервісів, лише системний будильник ----------
object Reminders {
    private const val CH = "reminders"

    fun get(id: Long): Long? = Store.prefs.getLong("rem_$id", 0L).takeIf { it > 0 }

    fun all(): Map<Long, Long> {
        val out = HashMap<Long, Long>()
        Store.prefs.all.forEach { (k, v) ->
            if (k.startsWith("rem_") && v is Long) k.removePrefix("rem_").toLongOrNull()?.let { out[it] = v }
        }
        return out
    }

    private fun alarmIntent(ctx: Context, id: Long): PendingIntent = PendingIntent.getBroadcast(
        ctx, id.toInt(), Intent(ctx, ReminderReceiver::class.java).putExtra("id", id),
        PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
    )

    fun schedule(ctx: Context, id: Long, at: Long) {
        ctx.getSystemService(AlarmManager::class.java).setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, alarmIntent(ctx, id))
    }

    fun set(ctx: Context, id: Long, at: Long) {
        Store.prefs.edit().putLong("rem_$id", at).apply()
        schedule(ctx, id, at)
    }

    fun cancel(ctx: Context, id: Long) {
        Store.prefs.edit().remove("rem_$id").apply()
        ctx.getSystemService(AlarmManager::class.java).cancel(alarmIntent(ctx, id))
    }

    /** Сповіщення без вмісту нотатки — лише загальний текст. */
    fun fire(ctx: Context, id: Long) {
        App.lang = Store.prefs.getString("lang", "uk") ?: "uk"
        Store.prefs.edit().remove("rem_$id").apply()
        val nm = ctx.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CH, tr("Нагадування", "Reminders"), NotificationManager.IMPORTANCE_DEFAULT))
        val open = PendingIntent.getActivity(
            ctx, id.toInt(),
            Intent(ctx, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n = Notification.Builder(ctx, CH)
            .setSmallIcon(android.R.drawable.ic_popup_reminder)
            .setContentTitle(tr("Нагадування", "Reminder"))
            .setContentText(tr("Відкрийте нотатку в блокноті", "Open your note in the notebook"))
            .setContentIntent(open).setAutoCancel(true)
            .setVisibility(Notification.VISIBILITY_PRIVATE)
            .build()
        nm.notify(id.toInt(), n)
    }
}

class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        Store.init(context.applicationContext)
        val id = intent.getLongExtra("id", 0L)
        if (id != 0L) Reminders.fire(context, id)
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Intent.ACTION_BOOT_COMPLETED) return
        Store.init(context.applicationContext)
        val now = System.currentTimeMillis()
        Reminders.all().forEach { (id, at) -> if (at > now) Reminders.schedule(context, id, at) else Reminders.fire(context, id) }
    }
}

private fun at(days: Int, h: Int, m: Int): Long {
    val c = Calendar.getInstance()
    c.add(Calendar.DAY_OF_YEAR, days)
    c.set(Calendar.HOUR_OF_DAY, h); c.set(Calendar.MINUTE, m); c.set(Calendar.SECOND, 0); c.set(Calendar.MILLISECOND, 0)
    return c.timeInMillis
}

@Composable
fun ReminderDialog(noteId: Long, onClose: () -> Unit) {
    val ctx = LocalContext.current
    var step by remember { mutableIntStateOf(0) }
    var dateUtc by remember { mutableLongStateOf(System.currentTimeMillis()) }
    val cur = remember { Reminders.get(noteId) }
    val perm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }
    LaunchedEffect(Unit) {
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) perm.launch(Manifest.permission.POST_NOTIFICATIONS)
    }
    fun setAt(ms: Long) {
        Reminders.set(ctx, noteId, ms)
        val f = SimpleDateFormat("d MMM, HH:mm", Locale(App.lang)).format(Date(ms))
        Toast.makeText(ctx, tr("Нагадування: $f", "Reminder: $f"), Toast.LENGTH_SHORT).show()
        onClose()
    }
    when (step) {
        0 -> AlertDialog(
            onDismissRequest = onClose,
            title = { Text("🔔 " + tr("Нагадування", "Reminder")) },
            text = {
                Column {
                    if (cur != null) {
                        Text(
                            tr("Зараз: ", "Now: ") + SimpleDateFormat("d MMM yyyy, HH:mm", Locale(App.lang)).format(Date(cur)),
                            color = MaterialTheme.colorScheme.primary
                        )
                        Spacer(Modifier.height(8.dp))
                    }
                    TextButton(onClick = { setAt(System.currentTimeMillis() + 3_600_000L) }) { Text(tr("Через 1 годину", "In 1 hour")) }
                    TextButton(onClick = {
                        var t = at(0, 20, 0)
                        if (t < System.currentTimeMillis() + 60_000L) t = at(1, 20, 0)
                        setAt(t)
                    }) { Text(tr("Ввечері, 20:00", "This evening, 20:00")) }
                    TextButton(onClick = { setAt(at(1, 9, 0)) }) { Text(tr("Завтра вранці, 09:00", "Tomorrow morning, 09:00")) }
                    TextButton(onClick = { step = 1 }) { Text(tr("Обрати дату й час…", "Pick date and time…")) }
                    if (cur != null) {
                        TextButton(onClick = { Reminders.cancel(ctx, noteId); onClose() }) {
                            Text(tr("Видалити нагадування", "Remove reminder"), color = MaterialTheme.colorScheme.error)
                        }
                    }
                }
            },
            confirmButton = {},
            dismissButton = { TextButton(onClick = onClose) { Text(tr("Закрити", "Close")) } }
        )
        1 -> {
            val st = rememberDatePickerState(initialSelectedDateMillis = System.currentTimeMillis())
            DatePickerDialog(
                onDismissRequest = onClose,
                confirmButton = { TextButton(onClick = { dateUtc = st.selectedDateMillis ?: dateUtc; step = 2 }) { Text(tr("Далі", "Next")) } },
                dismissButton = { TextButton(onClick = onClose) { Text(tr("Скасувати", "Cancel")) } }
            ) { DatePicker(state = st) }
        }
        else -> {
            val ts = rememberTimePickerState(initialHour = 9, initialMinute = 0, is24Hour = true)
            AlertDialog(
                onDismissRequest = onClose,
                text = { TimePicker(state = ts) },
                confirmButton = {
                    TextButton(onClick = {
                        val d = java.time.Instant.ofEpochMilli(dateUtc).atZone(java.time.ZoneOffset.UTC).toLocalDate()
                        val ms = d.atTime(ts.hour, ts.minute).atZone(java.time.ZoneId.systemDefault()).toInstant().toEpochMilli()
                        if (ms <= System.currentTimeMillis()) {
                            Toast.makeText(ctx, tr("Оберіть майбутній час", "Pick a future time"), Toast.LENGTH_SHORT).show()
                        } else setAt(ms)
                    }) { Text("OK") }
                },
                dismissButton = { TextButton(onClick = onClose) { Text(tr("Скасувати", "Cancel")) } }
            )
        }
    }
}

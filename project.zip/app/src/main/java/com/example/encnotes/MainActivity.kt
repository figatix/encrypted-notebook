package com.example.encnotes

import android.os.Bundle
import android.view.MotionEvent
import android.view.WindowManager
import androidx.activity.compose.setContent
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.fragment.app.FragmentActivity
import kotlinx.coroutines.delay

class MainActivity : FragmentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // FLAG_SECURE: без скріншотів і без прев'ю у списку нещодавніх застосунків
        window.setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE)
        Store.init(applicationContext)
        App.lang = Store.prefs.getString("lang", "uk") ?: "uk"
        if (App.pin == null) App.screen = if (Auth.isSetup()) Screen.Login else Screen.Onboarding
        setContent { AppTheme { Root(this) } }
    }

    override fun onStart() {
        super.onStart()
        App.checkAutoLock()
    }

    override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
        App.touch()
        return super.dispatchTouchEvent(ev)
    }
}

@Composable
fun Root(act: FragmentActivity) {
    LaunchedEffect(Unit) {
        while (true) {
            delay(1000)
            App.checkAutoLock()
        }
    }
    when (val s = App.screen) {
        Screen.Onboarding -> OnboardingScreen()
        Screen.Setup -> SetupScreen()
        Screen.Login -> LoginScreen(act)
        Screen.Notes -> NotesScreen()
        Screen.Settings -> SettingsScreen(act)
        Screen.Help -> HelpScreen()
        is Screen.Editor -> EditorScreen(s.id)
    }
}

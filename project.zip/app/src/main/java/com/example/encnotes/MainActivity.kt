package com.example.encnotes

import android.os.Bundle
import android.view.WindowManager
import androidx.activity.compose.setContent
import androidx.compose.runtime.Composable
import androidx.fragment.app.FragmentActivity

class MainActivity : FragmentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // FLAG_SECURE: без скріншотів і без прев'ю у списку нещодавніх застосунків
        window.setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE)
        Store.init(applicationContext)
        App.lang = Store.prefs.getString("lang", "uk") ?: "uk"
        if (App.pin == null) App.screen = when {
            Auth.isSetup() -> Screen.Login
            Auth.needsMigration() -> Screen.Migrate
            else -> Screen.Onboarding
        }
        setContent { AppTheme { Root(this) } }
    }

    override fun onStop() {
        super.onStop()
        App.onStop()
    }

    override fun onStart() {
        super.onStart()
        App.onStart()
    }
}

@Composable
fun Root(act: FragmentActivity) {
    when (val s = App.screen) {
        Screen.Onboarding -> OnboardingScreen()
        Screen.Setup -> SetupScreen()
        Screen.Login -> LoginScreen(act)
        Screen.Migrate -> MigrateScreen()
        Screen.Notes -> NotesScreen()
        Screen.Settings -> SettingsScreen(act)
        Screen.Help -> HelpScreen()
        is Screen.Editor -> EditorScreen(s.id)
    }
}

@file:OptIn(ExperimentalMaterial3Api::class, ExperimentalFoundationApi::class)

package com.example.encnotes

import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.staggeredgrid.LazyVerticalStaggeredGrid
import androidx.compose.foundation.lazy.staggeredgrid.StaggeredGridCells
import androidx.compose.foundation.lazy.staggeredgrid.StaggeredGridItemSpan
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextRange
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.unit.sp
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.security.SecureRandom
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

data class Item(val e: NoteEntity, val title: String, val body: String, val tags: String)

private fun toItem(e: NoteEntity, v: Vault?): Item {
    if (v == null) return Item(e, e.title.take(28), e.body.take(90), "")
    val p = Auth.decrypt(e, v)
    return Item(e, p.title, p.body, p.tags)
}

private fun dateLabel(ms: Long, tf: SimpleDateFormat): String {
    val now = Calendar.getInstance()
    val c = Calendar.getInstance().apply { timeInMillis = ms }
    if (now.get(Calendar.YEAR) == c.get(Calendar.YEAR) && now.get(Calendar.DAY_OF_YEAR) == c.get(Calendar.DAY_OF_YEAR)) {
        return tf.format(Date(ms))
    }
    val month = SimpleDateFormat("LLLL", Locale(App.lang)).format(Date(ms)).replaceFirstChar { it.uppercase() }
    val year = if (now.get(Calendar.YEAR) != c.get(Calendar.YEAR)) " ${c.get(Calendar.YEAR)}" else ""
    return "${c.get(Calendar.DAY_OF_MONTH)} $month$year"
}

@Composable
fun NotesScreen() {
    val scope = rememberCoroutineScope()
    val vault = App.vault
    var items by remember { mutableStateOf(listOf<Item>()) }
    var loaded by remember { mutableStateOf(false) }
    var q by remember { mutableStateOf(App.query) }
    var searching by remember { mutableStateOf(App.query.isNotBlank()) }
    val searchFocus = remember { FocusRequester() }
    var menu by remember { mutableStateOf(false) }
    var showImport by remember { mutableStateOf(false) }
    var showKey by remember { mutableStateOf(false) }
    var pending by remember { mutableStateOf<(() -> Unit)?>(null) }
    var exportText by remember { mutableStateOf<String?>(null) }
    var selected by remember { mutableStateOf(setOf<Long>()) }
    var confirmDelete by remember { mutableStateOf(false) }
    val tf = remember(App.lang) { SimpleDateFormat("HH:mm", Locale(App.lang)) }
    val selecting = selected.isNotEmpty()

    /** Ключ питаємо лише коли він справді потрібен; після введення він діє до блокування. */
    fun requireKey(action: () -> Unit) {
        if (App.vault != null) action() else { pending = action; showKey = true }
    }
    suspend fun reload() {
        val list = Store.db.dao().all()
        val v = App.vault
        items = withContext(Dispatchers.Default) { list.map { toItem(it, v) } }
        loaded = true
    }

    LaunchedEffect(vault) { reload() }
    BackHandler(selecting) { selected = emptySet() }
    BackHandler(searching && !selecting) { searching = false; q = ""; App.query = "" }
    LaunchedEffect(searching) {
        if (searching) { delay(100); try { searchFocus.requestFocus() } catch (e: Exception) {} }
    }

    val shown = if (vault != null && q.isNotBlank()) items.filter { (it.title + " " + it.body + " " + it.tags).contains(q, ignoreCase = true) } else items

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        floatingActionButton = {
            if (!selecting) FloatingActionButton(
                onClick = {
                    val go = { App.query = q; App.screen = Screen.Editor(0) }
                    if (Auth.mode() == "C1") requireKey(go) else go()
                },
                shape = CircleShape, containerColor = MaterialTheme.colorScheme.primary,
                contentColor = MaterialTheme.colorScheme.onPrimary,
                modifier = Modifier.size(64.dp)
            ) { Icon(Icons.Default.Add, tr("Нова нотатка", "New note"), Modifier.size(32.dp)) }
        },
        bottomBar = {
            if (selecting) Surface(color = MaterialTheme.colorScheme.surface, tonalElevation = 2.dp) {
                Row(Modifier.fillMaxWidth().padding(8.dp), horizontalArrangement = Arrangement.Center) {
                    TextButton(onClick = { confirmDelete = true }) {
                        Icon(Icons.Default.Delete, null)
                        Spacer(Modifier.width(8.dp))
                        Text(tr("Видалити", "Delete"))
                    }
                }
            }
        }
    ) { pad ->
        Column(Modifier.padding(pad).fillMaxSize()) {
            if (searching && vault != null && !selecting) {
                Row(Modifier.fillMaxWidth().padding(start = 12.dp, end = 8.dp, top = 8.dp, bottom = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                    TextField(
                        value = q, onValueChange = { q = it; App.query = it }, singleLine = true,
                        leadingIcon = { Icon(Icons.Default.Search, null) },
                        trailingIcon = if (q.isNotEmpty()) ({
                            IconButton(onClick = { q = ""; App.query = "" }) { Icon(Icons.Default.Close, null) }
                        }) else null,
                        shape = RoundedCornerShape(28.dp),
                        colors = TextFieldDefaults.colors(
                            focusedContainerColor = MaterialTheme.colorScheme.surface, unfocusedContainerColor = MaterialTheme.colorScheme.surface,
                            focusedIndicatorColor = Color.Transparent, unfocusedIndicatorColor = Color.Transparent
                        ),
                        modifier = Modifier.weight(1f).focusRequester(searchFocus)
                    )
                    TextButton(onClick = { searching = false; q = ""; App.query = "" }) {
                        Text(tr("Скасувати", "Cancel"), color = Color(0xFF3B82F6), style = MaterialTheme.typography.titleMedium)
                    }
                }
            } else Row(Modifier.fillMaxWidth().padding(start = 8.dp, end = 8.dp, top = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                if (selecting) {
                    IconButton(onClick = { selected = emptySet() }) { Icon(Icons.Default.Close, null) }
                    Text(tr("Обрано: ${selected.size}", "Selected: ${selected.size}"), style = MaterialTheme.typography.titleMedium)
                    Spacer(Modifier.weight(1f))
                    TextButton(onClick = { selected = shown.map { it.e.id }.toSet() }) { Text(tr("Усі", "All")) }
                } else {
                    Spacer(Modifier.weight(1f))
                    IconButton(onClick = { App.lock() }) { Icon(Icons.Default.Lock, tr("Заблокувати", "Lock")) }
                    IconButton(onClick = { App.query = ""; App.screen = Screen.Settings }) { Icon(Icons.Default.Settings, tr("Налаштування", "Settings")) }
                    Box {
                        IconButton(onClick = { menu = true }) { Icon(Icons.Default.MoreVert, null) }
                        DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                            DropdownMenuItem(text = { Text(tr("Експорт усіх нотаток", "Export all notes")) }, onClick = {
                                menu = false
                                requireKey {
                                    val k = App.vault?.keyText
                                    if (k != null) scope.launch {
                                        exportText = withContext(Dispatchers.Default) { Transfer.export(Auth.plainAll(), k) }
                                    }
                                }
                            })
                            DropdownMenuItem(text = { Text(tr("Імпорт", "Import")) }, onClick = { menu = false; requireKey { showImport = true } })
                        }
                    }
                }
            }
            LazyVerticalStaggeredGrid(
                columns = StaggeredGridCells.Fixed(2),
                contentPadding = PaddingValues(start = 12.dp, end = 12.dp, bottom = 120.dp),
                verticalItemSpacing = 10.dp,
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.fillMaxSize()
            ) {
                if (!searching) {
                    item(key = "title", span = StaggeredGridItemSpan.FullLine) {
                        Column(Modifier.padding(start = 8.dp, top = 4.dp, bottom = 8.dp)) {
                            Text(tr("Нотатки", "Notes"), style = MaterialTheme.typography.displaySmall, fontWeight = FontWeight.Bold)
                            Text(tr("Усього: ${items.size}", "Total: ${items.size}"), style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                    item(key = "search", span = StaggeredGridItemSpan.FullLine) {
                        Box(Modifier.padding(bottom = 6.dp)) {
                            if (vault == null) {
                                Card(
                                    onClick = { showKey = true }, shape = RoundedCornerShape(28.dp),
                                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Text(
                                        tr("🔑 Нотатки зашифровані. Торкніться, щоб ввести ключ і побачити текст.",
                                            "🔑 Notes are encrypted. Tap to enter the key and see the text."),
                                        modifier = Modifier.padding(horizontal = 20.dp, vertical = 14.dp),
                                        color = MaterialTheme.colorScheme.onPrimaryContainer
                                    )
                                }
                            } else {
                                Card(
                                    onClick = { searching = true }, shape = RoundedCornerShape(28.dp),
                                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Row(Modifier.padding(horizontal = 20.dp, vertical = 14.dp), verticalAlignment = Alignment.CenterVertically) {
                                        Icon(Icons.Default.Search, null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
                                        Spacer(Modifier.width(12.dp))
                                        Text(tr("Пошук нотаток", "Search notes"), color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    }
                                }
                            }
                        }
                    }
                }
                if (shown.isEmpty() && loaded) {
                    item(key = "empty", span = StaggeredGridItemSpan.FullLine) {
                        Box(Modifier.fillMaxWidth().padding(top = 80.dp), contentAlignment = Alignment.Center) {
                            Text(
                                if (q.isNotBlank()) tr("Нічого не знайдено", "Nothing found")
                                else tr("Натисніть +, щоб створити першу нотатку", "Tap + to create your first note"),
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
                items(shown, key = { it.e.id }) { n ->
                    NoteRow(
                        n, if (vault != null) q else "", tf, selecting, n.e.id in selected,
                        onClick = {
                            if (selecting) selected = if (n.e.id in selected) selected - n.e.id else selected + n.e.id
                            else requireKey { App.query = q; App.screen = Screen.Editor(n.e.id) }
                        },
                        onLong = { selected = selected + n.e.id }
                    )
                }
            }
        }
    }

    if (confirmDelete) {
        AlertDialog(
            onDismissRequest = { confirmDelete = false },
            title = { Text(tr("Видалити нотатки?", "Delete notes?")) },
            text = { Text(tr("Вибрано: ${selected.size}. Відновити їх буде неможливо.", "Selected: ${selected.size}. They cannot be recovered.")) },
            confirmButton = { TextButton(onClick = {
                confirmDelete = false
                val ids = selected
                selected = emptySet()
                scope.launch { ids.forEach { Store.db.dao().delete(it) }; reload() }
            }) { Text(tr("Видалити", "Delete")) } },
            dismissButton = { TextButton(onClick = { confirmDelete = false }) { Text(tr("Скасувати", "Cancel")) } }
        )
    }
    if (showKey) KeyDialog(
        onDismiss = { showKey = false; pending = null },
        onUnlocked = { val a = pending; pending = null; showKey = false; a?.invoke() }
    )
    exportText?.let { ExportDialog(it) { exportText = null } }
    if (showImport) ImportDialog(onDone = { showImport = false; scope.launch { reload() } })
}

@Composable
fun KeyDialog(onDismiss: () -> Unit, onUnlocked: () -> Unit) {
    val scope = rememberCoroutineScope()
    var key by remember { mutableStateOf("") }
    var err by remember { mutableStateOf<String?>(null) }
    var ver by remember { mutableIntStateOf(0) }
    var busy by remember { mutableStateOf(false) }
    val rem = rememberRemaining(Auth.keyLock, ver)
    val numeric = Auth.mode() == "C1"
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(tr("Введіть ключ", "Enter key")) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(tr("Введіть ключ, щоб побачити справжній текст. Без ключа ви побачите зашифровані символи.",
                    "Enter the key to see the real text. Without the key you will see encrypted characters."))
                if (rem > 0) {
                    Text(tr("Забагато спроб. Спробуйте через ${fmt(rem)}", "Too many attempts. Try again in ${fmt(rem)}"),
                        color = MaterialTheme.colorScheme.error)
                } else {
                    Field(tr("Ключ", "Key"), key, { key = if (numeric) it.filter { c -> c in '0'..'9' }.take(18) else it }, secret = true, numeric = numeric)
                    err?.let { Text(it, color = MaterialTheme.colorScheme.error) }
                }
            }
        },
        confirmButton = {
            Button(enabled = rem <= 0 && !busy && key.isNotEmpty(), onClick = {
                scope.launch {
                    busy = true
                    val pin = App.pin
                    val v = if (pin == null) null else withContext(Dispatchers.Default) { Auth.unlockKey(pin, key) }
                    busy = false
                    if (v != null) {
                        Auth.keyLock.reset(); App.vault = v; onUnlocked()
                    } else {
                        val left = Auth.keyLock.fail()
                        ver++; key = ""
                        err = if (left > 0) tr("Невірний ключ. Спробуйте ще раз. Залишилось спроб: $left",
                            "Wrong key. Try again. Attempts left: $left") else null
                    }
                }
            }) { if (busy) CircularProgressIndicator(Modifier.size(20.dp), strokeWidth = 2.dp) else Text("OK") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text(tr("Скасувати", "Cancel")) } }
    )
}

@Composable
fun NoteRow(
    n: Item, q: String, tf: SimpleDateFormat, selecting: Boolean, selected: Boolean,
    onClick: () -> Unit, onLong: () -> Unit
) {
    val hl = MaterialTheme.colorScheme.primary.copy(alpha = 0.35f)
    val shape = RoundedCornerShape(24.dp)
    val sub = MaterialTheme.colorScheme.onSurfaceVariant
    Surface(
        shape = shape,
        color = if (selected) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surface,
        modifier = Modifier.fillMaxWidth().clip(shape).combinedClickable(onClick = onClick, onLongClick = onLong)
    ) {
        Column(Modifier.padding(horizontal = 18.dp, vertical = 18.dp)) {
            if (n.title.isNotBlank() || n.body.isBlank()) {
                Text(
                    highlight(n.title.ifBlank { tr("Без назви", "Untitled") }, q, hl),
                    style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold,
                    maxLines = 1, overflow = TextOverflow.Ellipsis
                )
            }
            val sn = if (q.isBlank()) n.body.trim().take(240) else snippet(n.body, q)
            if (sn.isNotBlank()) {
                Spacer(Modifier.height(10.dp))
                Text(
                    highlight(sn, q, hl), style = MaterialTheme.typography.bodyMedium,
                    color = sub, maxLines = 4, overflow = TextOverflow.Ellipsis
                )
            } else {
                Spacer(Modifier.height(10.dp))
                Text(tr("Немає тексту", "No text"), style = MaterialTheme.typography.bodyMedium, color = sub)
            }
            Spacer(Modifier.height(12.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(dateLabel(n.e.updated, tf), style = MaterialTheme.typography.bodySmall, color = sub.copy(alpha = 0.8f), modifier = Modifier.weight(1f))
                if (selecting) Checkbox(checked = selected, onCheckedChange = null)
            }
        }
    }
}

@Composable
fun ExportDialog(text: String, onClose: () -> Unit) {
    val ctx = LocalContext.current
    AlertDialog(
        onDismissRequest = onClose,
        title = { Text(tr("Експорт", "Export")) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(tr("Скопіюйте цей текст і вставте його в іншому екземплярі застосунку (Меню → Імпорт), ввівши той самий ключ.",
                    "Copy this text and paste it into another copy of the app (Menu → Import), entering the same key."))
                OutlinedTextField(value = text, onValueChange = {}, readOnly = true, maxLines = 6, modifier = Modifier.fillMaxWidth())
                Text(tr("Текст захищений лише вашим ключем — зберігайте його обережно.",
                    "The text is protected only by your key — keep it safe."), style = MaterialTheme.typography.bodySmall)
            }
        },
        confirmButton = { Button(onClick = { Clip.copyPlain(ctx, text); onClose() }) { Text(tr("Копіювати", "Copy")) } },
        dismissButton = { TextButton(onClick = onClose) { Text(tr("Закрити", "Close")) } }
    )
}

@Composable
fun ImportDialog(onDone: () -> Unit) {
    val scope = rememberCoroutineScope()
    var text by remember { mutableStateOf("") }
    var key by remember { mutableStateOf("") }
    var msg by remember { mutableStateOf<String?>(null) }
    var busy by remember { mutableStateOf(false) }
    AlertDialog(
        onDismissRequest = onDone,
        title = { Text(tr("Імпорт", "Import")) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(tr("Вставте експортований текст і введіть ключ, яким він був створений.",
                    "Paste the exported text and enter the key it was created with."))
                Field(tr("Експортований текст", "Exported text"), text, { text = it }, singleLine = false, minLines = 3)
                Field(tr("Ключ", "Key"), key, { key = it }, secret = true)
                msg?.let { Text(it) }
            }
        },
        confirmButton = {
            Button(enabled = !busy && text.isNotBlank() && key.isNotBlank(), onClick = {
                scope.launch {
                    busy = true
                    val list = withContext(Dispatchers.Default) { Transfer.import(text, key) }
                    if (list == null) {
                        msg = tr("Не вдалося розшифрувати. Перевірте текст і ключ.", "Could not decrypt. Check the text and the key.")
                        busy = false
                    } else {
                        list.forEach { Auth.save(0, it.merged()) }
                        busy = false
                        onDone()
                    }
                }
            }) { Text(tr("Імпортувати", "Import")) }
        },
        dismissButton = { TextButton(onClick = onDone) { Text(tr("Скасувати", "Cancel")) } }
    )
}

@Composable
fun GenDialog(onUse: (String) -> Unit, onDismiss: () -> Unit) {
    var len by remember { mutableFloatStateOf(16f) }
    var up by remember { mutableStateOf(true) }
    var low by remember { mutableStateOf(true) }
    var dig by remember { mutableStateOf(true) }
    var sym by remember { mutableStateOf(true) }
    var out by remember { mutableStateOf("") }

    fun gen() {
        val pools = listOfNotNull(
            if (up) "ABCDEFGHIJKLMNOPQRSTUVWXYZ" else null,
            if (low) "abcdefghijklmnopqrstuvwxyz" else null,
            if (dig) "0123456789" else null,
            if (sym) "!@#$%^&*()-_=+[]{};:,.?/" else null
        )
        if (pools.isEmpty()) { out = ""; return }
        val r = SecureRandom()
        val all = pools.joinToString("")
        val chars = MutableList(len.toInt()) { all[r.nextInt(all.length)] }
        pools.forEachIndexed { i, p -> chars[i] = p[r.nextInt(p.length)] }
        java.util.Collections.shuffle(chars, r)
        out = chars.joinToString("")
    }
    LaunchedEffect(Unit) { gen() }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(tr("Генератор паролів", "Password generator")) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(out, style = MaterialTheme.typography.titleMedium)
                Text(tr("Довжина: ${len.toInt()}", "Length: ${len.toInt()}"))
                Slider(value = len, onValueChange = { len = it; gen() }, valueRange = 8f..64f, steps = 55)
                listOf(
                    Triple(tr("Великі літери", "Uppercase"), up) { v: Boolean -> up = v },
                    Triple(tr("Малі літери", "Lowercase"), low) { v: Boolean -> low = v },
                    Triple(tr("Цифри", "Digits"), dig) { v: Boolean -> dig = v },
                    Triple(tr("Символи", "Symbols"), sym) { v: Boolean -> sym = v }
                ).forEach { (n, v, set) ->
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(checked = v, onCheckedChange = { set(it); gen() })
                        Text(n)
                    }
                }
                TextButton(onClick = { gen() }) { Text(tr("Згенерувати ще", "Generate again")) }
            }
        },
        confirmButton = { Button(enabled = out.isNotEmpty(), onClick = { onUse(out) }) { Text(tr("Вставити в нотатку", "Insert into note")) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text(tr("Скасувати", "Cancel")) } }
    )
}

@Composable
fun EditorScreen(id: Long) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var title by remember { mutableStateOf("") }
    var body by remember { mutableStateOf(TextFieldValue("")) }
    var tags by remember { mutableStateOf("") }   // старі теги зберігаються без змін, але не показуються
    var orig by remember { mutableStateOf("") }
    var updated by remember { mutableLongStateOf(System.currentTimeMillis()) }
    var showGen by remember { mutableStateOf(false) }
    var showHint by remember { mutableStateOf(false) }
    var confirmDelete by remember { mutableStateOf(false) }
    var exportText by remember { mutableStateOf<String?>(null) }
    var menu by remember { mutableStateOf(false) }
    val focus = remember { FocusRequester() }
    val df = remember(App.lang) { SimpleDateFormat("d MMMM HH:mm", Locale(App.lang)) }
    val q = App.query
    val hl = MaterialTheme.colorScheme.primary.copy(alpha = 0.35f)
    val done = MaterialTheme.colorScheme.onSurfaceVariant

    // ---- скасувати / повторити ----
    val hist = remember { ArrayList<Pair<String, String>>() }
    var hpos by remember { mutableIntStateOf(0) }
    var hsize by remember { mutableIntStateOf(0) }
    var lastPush by remember { mutableLongStateOf(0L) }

    fun record() {
        val cur = title to body.text
        if (hist.isNotEmpty() && hist[hpos] == cur) return
        while (hist.size > hpos + 1) hist.removeAt(hist.size - 1)
        val now = System.currentTimeMillis()
        if (now - lastPush < 700 && hist.size > 1) hist[hist.size - 1] = cur else hist.add(cur)
        lastPush = now
        if (hist.size > 200) hist.removeAt(0)
        hpos = hist.size - 1
        hsize = hist.size
    }
    fun applyHist(p: Pair<String, String>) {
        title = p.first
        body = TextFieldValue(p.second, TextRange(p.second.length))
    }
    fun undo() { if (hpos > 0) { hpos--; applyHist(hist[hpos]) } }
    fun redo() { if (hpos < hist.size - 1) { hpos++; applyHist(hist[hpos]) } }

    // ---- чекліст: ☐ / ☑ на початку рядка ----
    fun onBody(nv: TextFieldValue) {
        var v = nv
        val c = nv.selection.start
        if (nv.selection.collapsed && nv.text.length == body.text.length + 1 && c > 0 && nv.text[c - 1] == '\n') {
            val ls = nv.text.lastIndexOf('\n', c - 2) + 1
            val prev = nv.text.substring(ls, c - 1)
            if (prev.startsWith("☐ ") || prev.startsWith("☑ ")) {
                v = if (prev.length <= 2) {
                    TextFieldValue(nv.text.removeRange(ls, c), TextRange(ls))
                } else {
                    TextFieldValue(nv.text.substring(0, c) + "☐ " + nv.text.substring(c), TextRange(c + 2))
                }
            }
        }
        body = v
        record()
    }
    fun toggleCheck() {
        val t = body.text
        val c = body.selection.start
        val ls = t.lastIndexOf('\n', c - 1) + 1
        var le = t.indexOf('\n', ls)
        if (le < 0) le = t.length
        val line = t.substring(ls, le)
        val (newLine, delta) = when {
            line.startsWith("☐ ") -> Pair("☑ " + line.substring(2), 0)
            line.startsWith("☑ ") -> Pair(line.substring(2), -2)
            else -> Pair("☐ " + line, 2)
        }
        val nt = t.substring(0, ls) + newLine + t.substring(le)
        body = TextFieldValue(nt, TextRange((c + delta).coerceIn(0, nt.length)))
        record()
    }

    fun snap() = title + "\u0000" + body.text + "\u0000" + tags

    LaunchedEffect(id) {
        val c = App.vault
        if (id != 0L && c != null) {
            Store.db.dao().get(id)?.let {
                val p = withContext(Dispatchers.Default) { Auth.decrypt(it, c) }
                title = p.title; body = TextFieldValue(p.body); tags = p.tags; updated = it.updated
            }
        } else if (id == 0L) {
            if (!Store.prefs.getBoolean("hint_note", false)) {
                showHint = true
                Store.prefs.edit().putBoolean("hint_note", true).apply()
            }
            delay(200)
            try { focus.requestFocus() } catch (e: Exception) {}
        }
        orig = snap()
        hist.clear(); hist.add(title to body.text); hpos = 0; hsize = 1
    }

    fun leave() {
        if ((title.isBlank() && body.text.isBlank()) || snap() == orig) { App.screen = Screen.Notes; return }
        val t = title
        val b = body.text
        scope.launch {
            Auth.save(id, PlainNote(t, b, "", tags))
            App.screen = Screen.Notes
        }
    }
    BackHandler { leave() }

    val on = MaterialTheme.colorScheme.onSurface
    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        topBar = {
            TopAppBar(
                title = {},
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.Transparent),
                navigationIcon = { IconButton(onClick = { leave() }) { Icon(Icons.AutoMirrored.Filled.ArrowBack, null) } },
                actions = {
                    IconButton(onClick = { undo() }, enabled = hpos > 0) {
                        Text("↶", fontSize = 26.sp, color = if (hpos > 0) on else on.copy(alpha = 0.3f))
                    }
                    IconButton(onClick = { redo() }, enabled = hpos < hsize - 1) {
                        Text("↷", fontSize = 26.sp, color = if (hpos < hsize - 1) on else on.copy(alpha = 0.3f))
                    }
                    IconButton(onClick = { leave() }) { Icon(Icons.Default.Check, tr("Готово", "Done")) }
                    Box {
                        IconButton(onClick = { menu = true }) { Icon(Icons.Default.MoreVert, null) }
                        DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                            DropdownMenuItem(text = { Text(tr("Копіювати текст (очиститься за 30 с)", "Copy text (clears in 30 s)")) }, onClick = {
                                menu = false
                                Clip.copySecret(ctx, if (title.isBlank()) body.text else title + "\n" + body.text)
                                Toast.makeText(ctx, tr("Скопійовано. Буфер очиститься через 30 с.", "Copied. Clipboard clears in 30 s."), Toast.LENGTH_SHORT).show()
                            })
                            if (id != 0L) {
                                DropdownMenuItem(text = { Text(tr("Експорт нотатки", "Export note")) }, onClick = {
                                    menu = false
                                    val k = App.vault?.keyText
                                    val t = title
                                    val b = body.text
                                    if (k != null) scope.launch {
                                        exportText = withContext(Dispatchers.Default) { Transfer.export(listOf(PlainNote(t, b, "", tags)), k) }
                                    }
                                })
                                DropdownMenuItem(text = { Text(tr("Видалити", "Delete")) }, onClick = { menu = false; confirmDelete = true })
                            }
                        }
                    }
                }
            )
        }
    ) { pad ->
        Column(Modifier.padding(pad).fillMaxSize()) {
            PlainField(
                title, { title = it; record() }, tr("Назва", "Title"),
                MaterialTheme.typography.headlineMedium.copy(fontWeight = FontWeight.Medium, color = MaterialTheme.colorScheme.onBackground),
                modifier = Modifier.fillMaxWidth(),
                singleLine = true, transform = HlTransform(q, hl)
            )
            Text(
                df.format(Date(updated)) + "  |  " + (title.length + body.text.length) + tr(" символів", " characters"),
                style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.8f),
                modifier = Modifier.padding(horizontal = 20.dp, vertical = 4.dp)
            )
            PlainFieldV(
                body, { onBody(it) }, tr("Почніть введення", "Start typing"),
                MaterialTheme.typography.bodyLarge.copy(color = MaterialTheme.colorScheme.onBackground, lineHeight = 28.sp, fontSize = 18.sp),
                modifier = Modifier.fillMaxWidth().weight(1f).focusRequester(focus),
                transform = BodyTransform(q, hl, done)
            )
            // нижня панель, як у MIUI Notes
            Row(
                Modifier.fillMaxWidth().background(MaterialTheme.colorScheme.surface).padding(vertical = 2.dp),
                horizontalArrangement = Arrangement.SpaceEvenly
            ) {
                IconButton(onClick = { toggleCheck() }) { Text("☑", fontSize = 26.sp, color = on) }
                IconButton(onClick = { showGen = true }) { Text("🔑", fontSize = 22.sp) }
            }
        }
    }

    if (showGen) GenDialog(
        onUse = {
            val t = body.text + (if (body.text.isBlank() || body.text.endsWith("\n")) "" else "\n") + it
            body = TextFieldValue(t, TextRange(t.length)); record(); showGen = false
        },
        onDismiss = { showGen = false }
    )
    exportText?.let { ExportDialog(it) { exportText = null } }
    if (showHint) {
        AlertDialog(
            onDismissRequest = { showHint = false },
            title = { Text(tr("Підказка", "Tip")) },
            text = { Text(tr("Пишіть усе в одній нотатці: паролі, коди, доступи. Кнопка ☑ внизу робить рядок пунктом списку. Нотатка шифрується й зберігається автоматично, коли ви виходите назад.",
                "Write everything in one note: passwords, codes, logins. The ☑ button below makes a line a checklist item. The note is encrypted and saved automatically when you go back.")) },
            confirmButton = { TextButton(onClick = { showHint = false }) { Text("OK") } }
        )
    }
    if (confirmDelete) {
        AlertDialog(
            onDismissRequest = { confirmDelete = false },
            title = { Text(tr("Видалити нотатку?", "Delete note?")) },
            text = { Text(tr("Відновити її буде неможливо.", "It cannot be recovered.")) },
            confirmButton = { TextButton(onClick = {
                confirmDelete = false
                scope.launch { Store.db.dao().delete(id); App.screen = Screen.Notes }
            }) { Text(tr("Видалити", "Delete")) } },
            dismissButton = { TextButton(onClick = { confirmDelete = false }) { Text(tr("Скасувати", "Cancel")) } }
        )
    }
}

@file:OptIn(ExperimentalMaterial3Api::class, ExperimentalFoundationApi::class)

package com.example.encnotes

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.staggeredgrid.LazyVerticalStaggeredGrid
import androidx.compose.foundation.lazy.staggeredgrid.StaggeredGridCells
import androidx.compose.foundation.lazy.staggeredgrid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.security.SecureRandom

data class Item(val e: NoteEntity, val title: String, val preview: String, val tags: String, val body: String)

private fun toItem(e: NoteEntity, c: KeyCtx?): Item =
    if (c == null) Item(e, e.title.take(28), e.body.take(80), "", "")
    else {
        val body = Methods.safeDec(e.body, c)
        Item(e, Methods.safeDec(e.title, c), body.replace('\n', ' ').take(100), Methods.safeDec(e.tags, c), body)
    }

@Composable
fun NotesScreen() {
    val scope = rememberCoroutineScope()
    val key = App.keyCtx
    var items by remember { mutableStateOf(listOf<Item>()) }
    var q by remember { mutableStateOf("") }
    var searching by remember { mutableStateOf(false) }
    var menu by remember { mutableStateOf(false) }
    var showKey by remember { mutableStateOf(false) }
    var showImport by remember { mutableStateOf(false) }
    var exportText by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(key) {
        val list = Store.db.dao().all()
        items = withContext(Dispatchers.Default) { list.map { toItem(it, key) } }
    }
    BackHandler(searching) { searching = false; q = "" }

    val shown = if (key != null && q.isNotBlank()) items.filter { (it.title + it.body + it.tags).contains(q, true) } else items

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    if (searching) {
                        TextField(value = q, onValueChange = { q = it }, singleLine = true,
                            placeholder = { Text(tr("Пошук", "Search")) }, modifier = Modifier.fillMaxWidth())
                    } else Text(tr("Нотатки", "Notes"))
                },
                actions = {
                    IconButton(onClick = {
                        if (key == null) showKey = true else { searching = !searching; if (!searching) q = "" }
                    }) { Icon(if (searching) Icons.Default.Close else Icons.Default.Search, null) }
                    IconButton(onClick = { App.lock() }) { Icon(Icons.Default.Lock, null) }
                    IconButton(onClick = { App.screen = Screen.Settings }) { Icon(Icons.Default.Settings, null) }
                    Box {
                        IconButton(onClick = { menu = true }) { Icon(Icons.Default.MoreVert, null) }
                        DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                            DropdownMenuItem(text = { Text(tr("Експорт усіх нотаток", "Export all notes")) }, onClick = {
                                menu = false
                                val k = App.keyNum
                                if (key == null || k == null) showKey = true
                                else scope.launch {
                                    exportText = withContext(Dispatchers.Default) { Transfer.export(Auth.plainAll(), k) }
                                }
                            })
                            DropdownMenuItem(text = { Text(tr("Імпорт", "Import")) }, onClick = {
                                menu = false
                                if (key == null) showKey = true else showImport = true
                            })
                        }
                    }
                }
            )
        },
        floatingActionButton = {
            FloatingActionButton(onClick = {
                if (key == null) showKey = true else App.screen = Screen.Editor(0)
            }) { Icon(Icons.Default.Add, tr("Нова нотатка", "New note")) }
        }
    ) { pad ->
        Column(Modifier.padding(pad).fillMaxSize()) {
            if (key == null) {
                Card(Modifier.fillMaxWidth().padding(8.dp)) {
                    Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text(tr("Нотатки зашифровані. Введіть ключ, щоб побачити справжній текст. Без ключа ви побачите зашифровані символи.",
                            "Notes are encrypted. Enter the key to see the real text. Without it you will see encrypted characters."))
                        Button(onClick = { showKey = true }) { Text(tr("Ввести ключ", "Enter key")) }
                    }
                }
            }
            if (shown.isEmpty()) {
                Box(Modifier.fillMaxSize().padding(32.dp), contentAlignment = Alignment.Center) {
                    Text(
                        if (q.isNotBlank()) tr("Нічого не знайдено", "Nothing found")
                        else tr("Натисніть +, щоб створити першу нотатку", "Tap + to create your first note")
                    )
                }
            } else {
                LazyVerticalStaggeredGrid(
                    columns = StaggeredGridCells.Fixed(2),
                    contentPadding = PaddingValues(8.dp),
                    verticalItemSpacing = 8.dp,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(shown, key = { it.e.id }) { it ->
                        Card(onClick = { if (key == null) showKey = true else App.screen = Screen.Editor(it.e.id) }) {
                            Column(Modifier.padding(12.dp)) {
                                Text(it.title, style = MaterialTheme.typography.titleMedium, maxLines = 2, overflow = TextOverflow.Ellipsis)
                                Spacer(Modifier.height(4.dp))
                                Text(it.preview, style = MaterialTheme.typography.bodyMedium, maxLines = 4, overflow = TextOverflow.Ellipsis)
                            }
                        }
                    }
                }
            }
        }
    }

    if (showKey) KeyDialog { showKey = false }
    exportText?.let { ExportDialog(it) { exportText = null } }
    if (showImport) ImportDialog(onDone = { showImport = false; scope.launch {
        val list = Store.db.dao().all()
        items = withContext(Dispatchers.Default) { list.map { toItem(it, App.keyCtx) } }
    } })
}

@Composable
fun KeyDialog(onDismiss: () -> Unit) {
    val scope = rememberCoroutineScope()
    var key by remember { mutableStateOf("") }
    var err by remember { mutableStateOf<String?>(null) }
    var ver by remember { mutableIntStateOf(0) }
    var busy by remember { mutableStateOf(false) }
    val rem = rememberRemaining(Auth.keyLock, ver)
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(tr("Введіть ключ", "Enter key")) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(tr("Введіть ключ, щоб побачити справжній текст. Без ключа ви побачите зашифровані символи.",
                    "Enter the key to see the real text. Without the key you will see encrypted characters."))
                if (rem > 0) {
                    Text(tr("Забагато спроб. Спробуйте через ${fmt(rem)}", "Too many attempts. Try again in ${fmt(rem)}"),
                        color = MaterialTheme.colorScheme.error)
                } else {
                    Field(tr("Головний ключ", "Master key"), key, { key = it.filter(Char::isDigit).take(18) }, secret = true, numeric = true)
                    err?.let { Text(it, color = MaterialTheme.colorScheme.error) }
                }
            }
        },
        confirmButton = {
            Button(enabled = rem <= 0 && !busy && key.isNotBlank(), onClick = {
                scope.launch {
                    busy = true
                    val pin = App.pin
                    val ctx = if (pin == null) null else withContext(Dispatchers.Default) { Auth.unlock(pin, key) }
                    busy = false
                    if (ctx != null) {
                        Auth.keyLock.reset(); App.keyCtx = ctx; onDismiss()
                    } else {
                        val left = Auth.keyLock.fail()
                        ver++; key = ""
                        err = if (left > 0) tr("Невірний ключ. Спробуйте ще раз. Залишилось спроб: $left",
                            "Wrong key. Try again. Attempts left: $left") else null
                    }
                }
            }) { Text(if (busy) "…" else "OK") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text(tr("Скасувати", "Cancel")) } }
    )
}

@Composable
fun ExportDialog(text: String, onClose: () -> Unit) {
    val ctx = LocalContext.current
    AlertDialog(
        onDismissRequest = onClose,
        title = { Text(tr("Експорт", "Export")) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(tr("Скопіюйте цей текст і вставте його в іншому екземплярі застосунку (Меню → Імпорт), ввівши той самий ключ.",
                    "Copy this text and paste it into another copy of the app (Menu → Import), entering the same key."))
                OutlinedTextField(value = text, onValueChange = {}, readOnly = true, maxLines = 6, modifier = Modifier.fillMaxWidth())
                Text(tr("Текст захищений лише вашим ключем — зберігайте його обережно.",
                    "The text is protected only by your key — keep it safe."), style = MaterialTheme.typography.bodySmall)
            }
        },
        confirmButton = { Button(onClick = { Clip.copyPlain(ctx, text); onClose() }) { Text(tr("Копіювати", "Copy")) } },
        dismissButton = { TextButton(onClick = onClose) { Text(tr("Закрити", "Close")) } }
    )
}

@Composable
fun ImportDialog(onDone: () -> Unit) {
    val scope = rememberCoroutineScope()
    var text by remember { mutableStateOf("") }
    var key by remember { mutableStateOf("") }
    var msg by remember { mutableStateOf<String?>(null) }
    var busy by remember { mutableStateOf(false) }
    AlertDialog(
        onDismissRequest = onDone,
        title = { Text(tr("Імпорт", "Import")) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(tr("Вставте експортований текст і введіть ключ, яким він був створений.",
                    "Paste the exported text and enter the key it was created with."))
                Field(tr("Експортований текст", "Exported text"), text, { text = it }, singleLine = false, minLines = 3)
                Field(tr("Головний ключ", "Master key"), key, { key = it.filter(Char::isDigit).take(18) }, secret = true, numeric = true)
                msg?.let { Text(it) }
            }
        },
        confirmButton = {
            Button(enabled = !busy && text.isNotBlank() && key.isNotBlank(), onClick = {
                val k = Auth.parseKey(key)
                scope.launch {
                    busy = true
                    val list = if (k == null) null else withContext(Dispatchers.Default) { Transfer.import(text, k) }
                    if (list == null) {
                        msg = tr("Не вдалося розшифрувати. Перевірте текст і ключ.", "Could not decrypt. Check the text and the key.")
                    } else {
                        list.forEach { Auth.save(0, it) }
                        busy = false
                        onDone()
                        return@launch
                    }
                    busy = false
                }
            }) { Text(tr("Імпортувати", "Import")) }
        },
        dismissButton = { TextButton(onClick = onDone) { Text(tr("Скасувати", "Cancel")) } }
    )
}

@Composable
fun GenDialog(onUse: (String) -> Unit, onDismiss: () -> Unit) {
    var len by remember { mutableFloatStateOf(16f) }
    var up by remember { mutableStateOf(true) }
    var low by remember { mutableStateOf(true) }
    var dig by remember { mutableStateOf(true) }
    var sym by remember { mutableStateOf(true) }
    var out by remember { mutableStateOf("") }

    fun gen() {
        val pools = listOfNotNull(
            if (up) "ABCDEFGHIJKLMNOPQRSTUVWXYZ" else null,
            if (low) "abcdefghijklmnopqrstuvwxyz" else null,
            if (dig) "0123456789" else null,
            if (sym) "!@#$%^&*()-_=+[]{};:,.?/" else null
        )
        if (pools.isEmpty()) { out = ""; return }
        val r = SecureRandom()
        val all = pools.joinToString("")
        val chars = MutableList(len.toInt()) { all[r.nextInt(all.length)] }
        pools.forEachIndexed { i, p -> chars[i] = p[r.nextInt(p.length)] }
        java.util.Collections.shuffle(chars, r)
        out = chars.joinToString("")
    }
    LaunchedEffect(Unit) { gen() }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(tr("Генератор паролів", "Password generator")) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(out, style = MaterialTheme.typography.titleMedium)
                Text(tr("Довжина: ${len.toInt()}", "Length: ${len.toInt()}"))
                Slider(value = len, onValueChange = { len = it; gen() }, valueRange = 8f..64f, steps = 55)
                listOf(
                    Triple(tr("Великі літери", "Uppercase"), up) { v: Boolean -> up = v },
                    Triple(tr("Малі літери", "Lowercase"), low) { v: Boolean -> low = v },
                    Triple(tr("Цифри", "Digits"), dig) { v: Boolean -> dig = v },
                    Triple(tr("Символи", "Symbols"), sym) { v: Boolean -> sym = v }
                ).forEach { (n, v, set) ->
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(checked = v, onCheckedChange = { set(it); gen() })
                        Text(n)
                    }
                }
                TextButton(onClick = { gen() }) { Text(tr("Згенерувати ще", "Generate again")) }
            }
        },
        confirmButton = { Button(enabled = out.isNotEmpty(), onClick = { onUse(out) }) { Text(tr("Використати", "Use")) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text(tr("Скасувати", "Cancel")) } }
    )
}

@Composable
fun EditorScreen(id: Long) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var title by remember { mutableStateOf("") }
    var body by remember { mutableStateOf("") }
    var pass by remember { mutableStateOf("") }
    var tags by remember { mutableStateOf("") }
    var orig by remember { mutableStateOf("") }
    var showGen by remember { mutableStateOf(false) }
    var showHint by remember { mutableStateOf(false) }
    var confirmDelete by remember { mutableStateOf(false) }
    var exportText by remember { mutableStateOf<String?>(null) }
    var showPass by remember { mutableStateOf(false) }

    fun snap() = listOf(title, body, pass, tags).joinToString("\u0000")

    LaunchedEffect(id) {
        val c = App.keyCtx
        if (id != 0L && c != null) {
            Store.db.dao().get(id)?.let {
                title = Methods.safeDec(it.title, c); body = Methods.safeDec(it.body, c)
                pass = Methods.safeDec(it.password, c); tags = Methods.safeDec(it.tags, c)
            }
        } else if (id == 0L && !Store.prefs.getBoolean("hint_note", false)) {
            showHint = true
            Store.prefs.edit().putBoolean("hint_note", true).apply()
        }
        orig = snap()
    }

    fun leave() {
        val empty = title.isBlank() && body.isBlank() && pass.isBlank() && tags.isBlank()
        if (empty || snap() == orig) { App.screen = Screen.Notes; return }
        scope.launch {
            Auth.save(id, PlainNote(title, body, pass, tags))
            App.screen = Screen.Notes
        }
    }
    BackHandler { leave() }

    Scaffold(topBar = {
        TopAppBar(
            title = { Text(if (id == 0L) tr("Нова нотатка", "New note") else tr("Нотатка", "Note")) },
            navigationIcon = { IconButton(onClick = { leave() }) { Icon(Icons.AutoMirrored.Filled.ArrowBack, null) } },
            actions = {
                if (id != 0L) {
                    IconButton(onClick = {
                        val k = App.keyNum
                        if (k != null) exportText = Transfer.export(listOf(PlainNote(title, body, pass, tags)), k)
                    }) { Icon(Icons.Default.Share, tr("Експорт", "Export")) }
                    IconButton(onClick = { confirmDelete = true }) { Icon(Icons.Default.Delete, tr("Видалити", "Delete")) }
                }
                IconButton(onClick = { leave() }) { Icon(Icons.Default.Check, tr("Зберегти", "Save")) }
            }
        )
    }) { pad ->
        Column(
            Modifier.padding(pad).padding(16.dp).verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Field(tr("Заголовок", "Title"), title, { title = it; App.touch() })
            Field(tr("Текст", "Text"), body, { body = it; App.touch() }, singleLine = false, minLines = 5)
            Field(tr("Пароль", "Password"), pass, { pass = it; App.touch() }, secret = !showPass,
                help = tr("Це поле можна скопіювати в буфер обміну — він автоматично очиститься через 30 секунд.",
                    "This field can be copied to the clipboard — it is cleared automatically after 30 seconds."))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                OutlinedButton(onClick = { Clip.copySecret(ctx, pass) }, enabled = pass.isNotEmpty()) { Text(tr("Копіювати", "Copy")) }
                OutlinedButton(onClick = { showGen = true }) { Text(tr("Згенерувати", "Generate")) }
                TextButton(onClick = { showPass = !showPass }) { Text(if (showPass) tr("Сховати", "Hide") else tr("Показати", "Show")) }
            }
            Field(tr("Теги", "Tags"), tags, { tags = it; App.touch() },
                help = tr("Необов'язково: слова через кому для пошуку. Теж шифруються.", "Optional: comma-separated words for search. Also encrypted."))
        }
    }

    if (showGen) GenDialog(onUse = { pass = it; showGen = false; App.touch() }, onDismiss = { showGen = false })
    exportText?.let { ExportDialog(it) { exportText = null } }
    if (showHint) {
        AlertDialog(
            onDismissRequest = { showHint = false },
            title = { Text(tr("Підказка", "Tip")) },
            text = { Text(tr("Введіть ключ, щоб побачити справжній текст. Без ключа ви побачите зашифровані символи. Нотатка зберігається автоматично, коли ви виходите.",
                "Enter the key to see the real text. Without the key you will see encrypted characters. The note is saved automatically when you leave.")) },
            confirmButton = { TextButton(onClick = { showHint = false }) { Text("OK") } }
        )
    }
    if (confirmDelete) {
        AlertDialog(
            onDismissRequest = { confirmDelete = false },
            title = { Text(tr("Видалити нотатку?", "Delete note?")) },
            text = { Text(tr("Відновити її буде неможливо.", "It cannot be recovered.")) },
            confirmButton = { TextButton(onClick = {
                confirmDelete = false
                scope.launch { Store.db.dao().delete(id); App.screen = Screen.Notes }
            }) { Text(tr("Видалити", "Delete")) } },
            dismissButton = { TextButton(onClick = { confirmDelete = false }) { Text(tr("Скасувати", "Cancel")) } }
        )
    }
}

@file:OptIn(ExperimentalMaterial3Api::class)

package com.example.encnotes

import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.security.SecureRandom
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class Item(val e: NoteEntity, val title: String, val body: String, val tags: String)

private fun toItem(e: NoteEntity, v: Vault?): Item {
    if (v == null) return Item(e, e.title.take(28), e.body.take(90), "")
    val p = Auth.decrypt(e, v)
    return Item(e, p.title, p.body, p.tags)
}

@Composable
fun NotesScreen() {
    val scope = rememberCoroutineScope()
    val vault = App.vault
    var items by remember { mutableStateOf(listOf<Item>()) }
    var loaded by remember { mutableStateOf(false) }
    var q by remember { mutableStateOf(App.query) }
    var menu by remember { mutableStateOf(false) }
    var showImport by remember { mutableStateOf(false) }
    var showKey by remember { mutableStateOf(false) }
    var pending by remember { mutableStateOf<(() -> Unit)?>(null) }
    var exportText by remember { mutableStateOf<String?>(null) }
    val df = remember(App.lang) { SimpleDateFormat("d MMM, HH:mm", Locale(App.lang)) }

    /** Ключ питаємо лише коли він справді потрібен; після введення він діє до блокування. */
    fun requireKey(action: () -> Unit) {
        if (App.vault != null) action() else { pending = action; showKey = true }
    }

    LaunchedEffect(vault) {
        val list = Store.db.dao().all()
        items = withContext(Dispatchers.Default) { list.map { toItem(it, vault) } }
        loaded = true
    }

    val shown = if (vault != null && q.isNotBlank()) items.filter { (it.title + " " + it.body + " " + it.tags).contains(q, ignoreCase = true) } else items

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        floatingActionButton = {
            FloatingActionButton(
                onClick = {
                    val go = { App.query = q; App.screen = Screen.Editor(0) }
                    if (Auth.mode() == "C1") requireKey(go) else go()
                },
                shape = CircleShape, containerColor = MaterialTheme.colorScheme.primary,
                contentColor = MaterialTheme.colorScheme.onPrimary
            ) { Icon(Icons.Default.Add, tr("Нова нотатка", "New note")) }
        }
    ) { pad ->
        Column(Modifier.padding(pad).fillMaxSize()) {
            Row(Modifier.fillMaxWidth().padding(start = 20.dp, end = 8.dp, top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(tr("Нотатки", "Notes"), style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.Bold)
                    Text(tr("Усього: ${items.size}", "Total: ${items.size}"), style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                IconButton(onClick = { App.lock() }) { Icon(Icons.Default.Lock, tr("Заблокувати", "Lock")) }
                IconButton(onClick = { App.query = ""; App.screen = Screen.Settings }) { Icon(Icons.Default.Settings, tr("Налаштування", "Settings")) }
                Box {
                    IconButton(onClick = { menu = true }) { Icon(Icons.Default.MoreVert, null) }
                    DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                        DropdownMenuItem(text = { Text(tr("Експорт усіх нотаток", "Export all notes")) }, onClick = {
                            menu = false
                            requireKey {
                                val k = App.vault?.keyText
                                if (k != null) scope.launch {
                                    exportText = withContext(Dispatchers.Default) { Transfer.export(Auth.plainAll(), k) }
                                }
                            }
                        })
                        DropdownMenuItem(text = { Text(tr("Імпорт", "Import")) }, onClick = { menu = false; requireKey { showImport = true } })
                    }
                }
            }
            if (vault == null) {
                Card(
                    onClick = { showKey = true }, shape = RoundedCornerShape(28.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp)
                ) {
                    Text(
                        tr("🔑 Нотатки зашифровані. Торкніться, щоб ввести ключ і побачити текст.",
                            "🔑 Notes are encrypted. Tap to enter the key and see the text."),
                        modifier = Modifier.padding(horizontal = 20.dp, vertical = 14.dp),
                        color = MaterialTheme.colorScheme.onPrimaryContainer
                    )
                }
            } else {
                TextField(
                    value = q, onValueChange = { q = it; App.query = it }, singleLine = true,
                    placeholder = { Text(tr("Пошук", "Search")) },
                    leadingIcon = { Icon(Icons.Default.Search, null) },
                    trailingIcon = if (q.isNotEmpty()) ({
                        IconButton(onClick = { q = ""; App.query = "" }) { Icon(Icons.Default.Close, null) }
                    }) else null,
                    shape = RoundedCornerShape(28.dp),
                    colors = TextFieldDefaults.colors(
                        focusedContainerColor = MaterialTheme.colorScheme.surface, unfocusedContainerColor = MaterialTheme.colorScheme.surface,
                        focusedIndicatorColor = Color.Transparent, unfocusedIndicatorColor = Color.Transparent
                    ),
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp)
                )
            }
            if (shown.isEmpty()) {
                if (loaded) {
                    Box(Modifier.fillMaxSize().padding(32.dp), contentAlignment = Alignment.Center) {
                        Text(
                            if (q.isNotBlank()) tr("Нічого не знайдено", "Nothing found")
                            else tr("Натисніть +, щоб створити першу нотатку", "Tap + to create your first note"),
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            } else {
                LazyColumn(
                    contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 4.dp, bottom = 96.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(shown, key = { it.e.id }) { n ->
                        NoteRow(n, if (vault != null) q else "", df) {
                            requireKey { App.query = q; App.screen = Screen.Editor(n.e.id) }
                        }
                    }
                }
            }
        }
    }

    if (showKey) KeyDialog(
        onDismiss = { showKey = false; pending = null },
        onUnlocked = { val a = pending; pending = null; showKey = false; a?.invoke() }
    )
    exportText?.let { ExportDialog(it) { exportText = null } }
    if (showImport) ImportDialog(onDone = {
        showImport = false
        scope.launch {
            val list = Store.db.dao().all()
            val v = App.vault
            items = withContext(Dispatchers.Default) { list.map { toItem(it, v) } }
        }
    })
}

@Composable
fun KeyDialog(onDismiss: () -> Unit, onUnlocked: () -> Unit) {
    val scope = rememberCoroutineScope()
    var key by remember { mutableStateOf("") }
    var err by remember { mutableStateOf<String?>(null) }
    var ver by remember { mutableIntStateOf(0) }
    var busy by remember { mutableStateOf(false) }
    val rem = rememberRemaining(Auth.keyLock, ver)
    val numeric = Auth.mode() == "C1"
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(tr("Введіть ключ", "Enter key")) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(tr("Введіть ключ, щоб побачити справжній текст. Без ключа ви побачите зашифровані символи.",
                    "Enter the key to see the real text. Without the key you will see encrypted characters."))
                if (rem > 0) {
                    Text(tr("Забагато спроб. Спробуйте через ${fmt(rem)}", "Too many attempts. Try again in ${fmt(rem)}"),
                        color = MaterialTheme.colorScheme.error)
                } else {
                    Field(tr("Ключ", "Key"), key, { key = if (numeric) it.filter { c -> c in '0'..'9' }.take(18) else it }, secret = true, numeric = numeric)
                    err?.let { Text(it, color = MaterialTheme.colorScheme.error) }
                }
            }
        },
        confirmButton = {
            Button(enabled = rem <= 0 && !busy && key.isNotEmpty(), onClick = {
                scope.launch {
                    busy = true
                    val pin = App.pin
                    val v = if (pin == null) null else withContext(Dispatchers.Default) { Auth.unlockKey(pin, key) }
                    busy = false
                    if (v != null) {
                        Auth.keyLock.reset(); App.vault = v; onUnlocked()
                    } else {
                        val left = Auth.keyLock.fail()
                        ver++; key = ""
                        err = if (left > 0) tr("Невірний ключ. Спробуйте ще раз. Залишилось спроб: $left",
                            "Wrong key. Try again. Attempts left: $left") else null
                    }
                }
            }) { if (busy) CircularProgressIndicator(Modifier.size(20.dp), strokeWidth = 2.dp) else Text("OK") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text(tr("Скасувати", "Cancel")) } }
    )
}

@Composable
fun NoteRow(n: Item, q: String, df: SimpleDateFormat, onClick: () -> Unit) {
    val hl = MaterialTheme.colorScheme.primary.copy(alpha = 0.35f)
    Card(
        onClick = onClick, shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(Modifier.padding(horizontal = 16.dp, vertical = 14.dp)) {
            Text(
                highlight(n.title.ifBlank { tr("Без назви", "Untitled") }, q, hl),
                style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold,
                maxLines = 1, overflow = TextOverflow.Ellipsis
            )
            val sn = snippet(n.body, q)
            if (sn.isNotBlank()) {
                Spacer(Modifier.height(4.dp))
                Text(
                    highlight(sn, q, hl), style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 2, overflow = TextOverflow.Ellipsis
                )
            }
            Spacer(Modifier.height(6.dp))
            Text(
                df.format(Date(n.e.updated)), style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f)
            )
        }
    }
}

@Composable
fun ExportDialog(text: String, onClose: () -> Unit) {
    val ctx = LocalContext.current
    AlertDialog(
        onDismissRequest = onClose,
        title = { Text(tr("Експорт", "Export")) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(tr("Скопіюйте цей текст і вставте його в іншому екземплярі застосунку (Меню → Імпорт), ввівши той самий ключ.",
                    "Copy this text and paste it into another copy of the app (Menu → Import), entering the same key."))
                OutlinedTextField(value = text, onValueChange = {}, readOnly = true, maxLines = 6, modifier = Modifier.fillMaxWidth())
                Text(tr("Текст захищений лише вашим ключем — зберігайте його обережно.",
                    "The text is protected only by your key — keep it safe."), style = MaterialTheme.typography.bodySmall)
            }
        },
        confirmButton = { Button(onClick = { Clip.copyPlain(ctx, text); onClose() }) { Text(tr("Копіювати", "Copy")) } },
        dismissButton = { TextButton(onClick = onClose) { Text(tr("Закрити", "Close")) } }
    )
}

@Composable
fun ImportDialog(onDone: () -> Unit) {
    val scope = rememberCoroutineScope()
    var text by remember { mutableStateOf("") }
    var key by remember { mutableStateOf("") }
    var msg by remember { mutableStateOf<String?>(null) }
    var busy by remember { mutableStateOf(false) }
    AlertDialog(
        onDismissRequest = onDone,
        title = { Text(tr("Імпорт", "Import")) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(tr("Вставте експортований текст і введіть ключ, яким він був створений.",
                    "Paste the exported text and enter the key it was created with."))
                Field(tr("Експортований текст", "Exported text"), text, { text = it }, singleLine = false, minLines = 3)
                Field(tr("Ключ", "Key"), key, { key = it }, secret = true)
                msg?.let { Text(it) }
            }
        },
        confirmButton = {
            Button(enabled = !busy && text.isNotBlank() && key.isNotBlank(), onClick = {
                scope.launch {
                    busy = true
                    val list = withContext(Dispatchers.Default) { Transfer.import(text, key) }
                    if (list == null) {
                        msg = tr("Не вдалося розшифрувати. Перевірте текст і ключ.", "Could not decrypt. Check the text and the key.")
                        busy = false
                    } else {
                        list.forEach { Auth.save(0, it.merged()) }
                        busy = false
                        onDone()
                    }
                }
            }) { Text(tr("Імпортувати", "Import")) }
        },
        dismissButton = { TextButton(onClick = onDone) { Text(tr("Скасувати", "Cancel")) } }
    )
}

@Composable
fun GenDialog(onUse: (String) -> Unit, onDismiss: () -> Unit) {
    var len by remember { mutableFloatStateOf(16f) }
    var up by remember { mutableStateOf(true) }
    var low by remember { mutableStateOf(true) }
    var dig by remember { mutableStateOf(true) }
    var sym by remember { mutableStateOf(true) }
    var out by remember { mutableStateOf("") }

    fun gen() {
        val pools = listOfNotNull(
            if (up) "ABCDEFGHIJKLMNOPQRSTUVWXYZ" else null,
            if (low) "abcdefghijklmnopqrstuvwxyz" else null,
            if (dig) "0123456789" else null,
            if (sym) "!@#$%^&*()-_=+[]{};:,.?/" else null
        )
        if (pools.isEmpty()) { out = ""; return }
        val r = SecureRandom()
        val all = pools.joinToString("")
        val chars = MutableList(len.toInt()) { all[r.nextInt(all.length)] }
        pools.forEachIndexed { i, p -> chars[i] = p[r.nextInt(p.length)] }
        java.util.Collections.shuffle(chars, r)
        out = chars.joinToString("")
    }
    LaunchedEffect(Unit) { gen() }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(tr("Генератор паролів", "Password generator")) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(out, style = MaterialTheme.typography.titleMedium)
                Text(tr("Довжина: ${len.toInt()}", "Length: ${len.toInt()}"))
                Slider(value = len, onValueChange = { len = it; gen() }, valueRange = 8f..64f, steps = 55)
                listOf(
                    Triple(tr("Великі літери", "Uppercase"), up) { v: Boolean -> up = v },
                    Triple(tr("Малі літери", "Lowercase"), low) { v: Boolean -> low = v },
                    Triple(tr("Цифри", "Digits"), dig) { v: Boolean -> dig = v },
                    Triple(tr("Символи", "Symbols"), sym) { v: Boolean -> sym = v }
                ).forEach { (n, v, set) ->
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(checked = v, onCheckedChange = { set(it); gen() })
                        Text(n)
                    }
                }
                TextButton(onClick = { gen() }) { Text(tr("Згенерувати ще", "Generate again")) }
            }
        },
        confirmButton = { Button(enabled = out.isNotEmpty(), onClick = { onUse(out) }) { Text(tr("Вставити в нотатку", "Insert into note")) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text(tr("Скасувати", "Cancel")) } }
    )
}

@Composable
fun EditorScreen(id: Long) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var title by remember { mutableStateOf("") }
    var body by remember { mutableStateOf("") }
    var tags by remember { mutableStateOf("") }
    var orig by remember { mutableStateOf("") }
    var updated by remember { mutableLongStateOf(System.currentTimeMillis()) }
    var showGen by remember { mutableStateOf(false) }
    var showHint by remember { mutableStateOf(false) }
    var confirmDelete by remember { mutableStateOf(false) }
    var exportText by remember { mutableStateOf<String?>(null) }
    var menu by remember { mutableStateOf(false) }
    val df = remember(App.lang) { SimpleDateFormat("d MMMM yyyy, HH:mm", Locale(App.lang)) }
    val q = App.query
    val hl = MaterialTheme.colorScheme.primary.copy(alpha = 0.35f)

    fun snap() = listOf(title, body, tags).joinToString("\u0000")

    LaunchedEffect(id) {
        val c = App.vault
        if (id != 0L && c != null) {
            Store.db.dao().get(id)?.let {
                val p = withContext(Dispatchers.Default) { Auth.decrypt(it, c) }
                title = p.title; body = p.body; tags = p.tags; updated = it.updated
            }
        } else if (id == 0L && !Store.prefs.getBoolean("hint_note", false)) {
            showHint = true
            Store.prefs.edit().putBoolean("hint_note", true).apply()
        }
        orig = snap()
    }

    fun leave() {
        val empty = title.isBlank() && body.isBlank() && tags.isBlank()
        if (empty || snap() == orig) { App.screen = Screen.Notes; return }
        scope.launch {
            Auth.save(id, PlainNote(title, body, "", tags))
            App.screen = Screen.Notes
        }
    }
    BackHandler { leave() }

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        topBar = {
            TopAppBar(
                title = {},
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.Transparent),
                navigationIcon = { IconButton(onClick = { leave() }) { Icon(Icons.AutoMirrored.Filled.ArrowBack, null) } },
                actions = {
                    IconButton(onClick = { leave() }) { Icon(Icons.Default.Check, tr("Зберегти", "Save")) }
                    Box {
                        IconButton(onClick = { menu = true }) { Icon(Icons.Default.MoreVert, null) }
                        DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                            DropdownMenuItem(text = { Text(tr("Копіювати текст (очиститься за 30 с)", "Copy text (clears in 30 s)")) }, onClick = {
                                menu = false
                                Clip.copySecret(ctx, body)
                                Toast.makeText(ctx, tr("Скопійовано. Буфер очиститься через 30 с.", "Copied. Clipboard clears in 30 s."), Toast.LENGTH_SHORT).show()
                            })
                            DropdownMenuItem(text = { Text(tr("Генератор паролів", "Password generator")) }, onClick = { menu = false; showGen = true })
                            if (id != 0L) {
                                DropdownMenuItem(text = { Text(tr("Експорт нотатки", "Export note")) }, onClick = {
                                    menu = false
                                    val k = App.vault?.keyText
                                    if (k != null) scope.launch {
                                        exportText = withContext(Dispatchers.Default) {
                                            Transfer.export(listOf(PlainNote(title, body, "", tags)), k)
                                        }
                                    }
                                })
                                DropdownMenuItem(text = { Text(tr("Видалити", "Delete")) }, onClick = { menu = false; confirmDelete = true })
                            }
                        }
                    }
                }
            )
        }
    ) { pad ->
        Column(Modifier.padding(pad).fillMaxSize().verticalScroll(rememberScrollState())) {
            PlainField(
                title, { title = it }, tr("Заголовок", "Title"),
                MaterialTheme.typography.headlineSmall.copy(fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onBackground),
                transform = HlTransform(q, hl)
            )
            Text(
                df.format(Date(updated)), style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(horizontal = 16.dp)
            )
            PlainField(
                body, { body = it }, tr("Почніть писати…", "Start writing…"),
                MaterialTheme.typography.bodyLarge.copy(color = MaterialTheme.colorScheme.onBackground),
                minLines = 10, transform = HlTransform(q, hl)
            )
            PlainField(
                tags, { tags = it }, tr("Теги через кому (необов'язково)", "Tags, comma-separated (optional)"),
                MaterialTheme.typography.bodyMedium.copy(color = MaterialTheme.colorScheme.onSurfaceVariant),
                singleLine = true
            )
            Spacer(Modifier.height(48.dp))
        }
    }

    if (showGen) GenDialog(
        onUse = { body = body + (if (body.isBlank() || body.endsWith("\n")) "" else "\n") + it; showGen = false },
        onDismiss = { showGen = false }
    )
    exportText?.let { ExportDialog(it) { exportText = null } }
    if (showHint) {
        AlertDialog(
            onDismissRequest = { showHint = false },
            title = { Text(tr("Підказка", "Tip")) },
            text = { Text(tr("Пишіть усе в одній нотатці: паролі, коди, доступи. Нотатка шифрується й зберігається автоматично, коли ви виходите назад.",
                "Write everything in one note: passwords, codes, logins. The note is encrypted and saved automatically when you go back.")) },
            confirmButton = { TextButton(onClick = { showHint = false }) { Text("OK") } }
        )
    }
    if (confirmDelete) {
        AlertDialog(
            onDismissRequest = { confirmDelete = false },
            title = { Text(tr("Видалити нотатку?", "Delete note?")) },
            text = { Text(tr("Відновити її буде неможливо.", "It cannot be recovered.")) },
            confirmButton = { TextButton(onClick = {
                confirmDelete = false
                scope.launch { Store.db.dao().delete(id); App.screen = Screen.Notes }
            }) { Text(tr("Видалити", "Delete")) } },
            dismissButton = { TextButton(onClick = { confirmDelete = false }) { Text(tr("Скасувати", "Cancel")) } }
        )
    }
}

@file:OptIn(ExperimentalMaterial3Api::class)

package com.example.encnotes

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val HrRe = Regex("^(-{3,}|\\*{3,}|_{3,})$")
val NumRe = Regex("^(\\d+)\\. ")

/** Підсвічування збігів пошуку (червоний текст) у вже готовому тексті */
fun addMatches(a: AnnotatedString, q: String): AnnotatedString {
    if (q.isBlank()) return a
    val b = AnnotatedString.Builder(a)
    var i = 0
    while (true) {
        val j = a.text.indexOf(q, i, ignoreCase = true)
        if (j < 0) break
        b.addStyle(SpanStyle(color = Color(0xFFFF4D4D)), j, j + q.length)
        i = j + q.length
    }
    return b.toAnnotatedString()
}

/** **жирний** і `код`; пробіли та відступи зберігаються як є */
fun inlineFmt(s: String, q: String, codeBg: Color): AnnotatedString {
    val b = AnnotatedString.Builder()
    var i = 0
    while (i < s.length) {
        if (s.startsWith("**", i)) {
            val j = s.indexOf("**", i + 2)
            if (j > i + 2) {
                b.pushStyle(SpanStyle(fontWeight = FontWeight.Bold)); b.append(s.substring(i + 2, j)); b.pop()
                i = j + 2
                continue
            }
        }
        if (s[i] == '`') {
            val j = s.indexOf('`', i + 1)
            if (j > i + 1) {
                b.pushStyle(SpanStyle(fontFamily = FontFamily.Monospace, background = codeBg)); b.append(s.substring(i + 1, j)); b.pop()
                i = j + 1
                continue
            }
        }
        b.append(s[i])
        i++
    }
    return addMatches(b.toAnnotatedString(), q)
}

/** Режим перегляду: красиве форматування. Торкніться тексту, щоб редагувати. */
@Composable
fun NoteView(title: String, meta: String, text: String, q: String, onToggle: (Int) -> Unit, onEdit: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val sub = cs.onSurfaceVariant
    val base = MaterialTheme.typography.bodyLarge.copy(fontSize = 17.sp, lineHeight = 27.sp, color = cs.onBackground)
    val codeBg = cs.surfaceVariant
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState())
            .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { onEdit() }
            .padding(horizontal = 20.dp)
    ) {
        if (title.isNotBlank()) {
            Text(
                addMatches(AnnotatedString(title), q),
                style = MaterialTheme.typography.headlineMedium.copy(fontWeight = FontWeight.Medium, color = cs.onBackground)
            )
        }
        Text(meta, style = MaterialTheme.typography.labelMedium, color = sub.copy(alpha = 0.8f), modifier = Modifier.padding(top = 6.dp, bottom = 14.dp))
        text.split("\n").forEachIndexed { i, raw ->
            val line = raw.trimEnd('\r')
            val s = line.trimStart()
            val ind = ((line.length - s.length) * 6).coerceAtMost(72).dp
            val num = NumRe.find(s)
            when {
                s.isEmpty() -> Spacer(Modifier.height(12.dp))
                HrRe.matches(s) -> HorizontalDivider(Modifier.padding(vertical = 14.dp), color = cs.outline)
                s.startsWith("### ") -> Text(
                    inlineFmt(s.substring(4), q, codeBg),
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, color = cs.onBackground),
                    modifier = Modifier.padding(start = ind, top = 8.dp, bottom = 2.dp)
                )
                s.startsWith("## ") -> Text(
                    inlineFmt(s.substring(3), q, codeBg),
                    style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold, color = cs.onBackground),
                    modifier = Modifier.padding(start = ind, top = 10.dp, bottom = 2.dp)
                )
                s.startsWith("# ") -> Text(
                    inlineFmt(s.substring(2), q, codeBg),
                    style = MaterialTheme.typography.headlineSmall.copy(fontWeight = FontWeight.Bold, color = cs.onBackground),
                    modifier = Modifier.padding(start = ind, top = 12.dp, bottom = 4.dp)
                )
                s.startsWith("☐ ") || s.startsWith("☑ ") -> {
                    val done = s.startsWith("☑ ")
                    Row(Modifier.padding(start = ind), verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(checked = done, onCheckedChange = { onToggle(i) })
                        Text(
                            inlineFmt(s.substring(2), q, codeBg),
                            style = base.copy(
                                color = if (done) sub else cs.onBackground,
                                textDecoration = if (done) TextDecoration.LineThrough else TextDecoration.None
                            )
                        )
                    }
                }
                s.startsWith("- ") || s.startsWith("• ") || s.startsWith("* ") -> Row(Modifier.padding(start = ind)) {
                    Text("•", style = base, modifier = Modifier.padding(end = 10.dp))
                    Text(inlineFmt(s.substring(2), q, codeBg), style = base)
                }
                num != null -> Row(Modifier.padding(start = ind)) {
                    Text(num.groupValues[1] + ".", style = base, modifier = Modifier.padding(end = 8.dp))
                    Text(inlineFmt(s.substring(num.value.length), q, codeBg), style = base)
                }
                s.startsWith("> ") -> Row(Modifier.padding(start = ind, top = 2.dp, bottom = 2.dp).height(IntrinsicSize.Min)) {
                    Box(Modifier.width(3.dp).fillMaxHeight().background(cs.primary))
                    Spacer(Modifier.width(10.dp))
                    Text(inlineFmt(s.substring(2), q, codeBg), style = base.copy(fontStyle = FontStyle.Italic, color = sub))
                }
                else -> Text(inlineFmt(line, q, codeBg), style = base)
            }
        }
        Spacer(Modifier.height(140.dp))
    }
}

@file:OptIn(ExperimentalMaterial3Api::class)

package com.example.encnotes

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import kotlinx.coroutines.delay

/** Переклад: читає стан мови, тому екрани оновлюються при перемиканні. */
fun tr(uk: String, en: String): String = if (App.lang == "uk") uk else en

@Composable
fun AppTheme(content: @Composable () -> Unit) {
    val dark = isSystemInDarkTheme()
    val c = LocalContext.current
    val scheme = when {
        Build.VERSION.SDK_INT >= 31 -> if (dark) dynamicDarkColorScheme(c) else dynamicLightColorScheme(c)
        dark -> darkColorScheme()
        else -> lightColorScheme()
    }
    MaterialTheme(colorScheme = scheme, content = content)
}

/** Іконка "?" з коротким поясненням */
@Composable
fun Help(text: String) {
    var open by remember { mutableStateOf(false) }
    IconButton(onClick = { open = true }) {
        Text("?", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
    }
    if (open) {
        AlertDialog(
            onDismissRequest = { open = false },
            confirmButton = { TextButton(onClick = { open = false }) { Text("OK") } },
            text = { Text(text) }
        )
    }
}

@Composable
fun Field(
    label: String, value: String, onChange: (String) -> Unit,
    help: String? = null, secret: Boolean = false, numeric: Boolean = false,
    singleLine: Boolean = true, minLines: Int = 1, modifier: Modifier = Modifier.fillMaxWidth()
) {
    OutlinedTextField(
        value = value, onValueChange = onChange, label = { Text(label) },
        singleLine = singleLine, minLines = minLines,
        visualTransformation = if (secret) PasswordVisualTransformation() else VisualTransformation.None,
        keyboardOptions = KeyboardOptions(keyboardType = if (numeric) KeyboardType.NumberPassword else KeyboardType.Text),
        trailingIcon = if (help != null) ({ Help(help) }) else null,
        modifier = modifier
    )
}

fun fmt(ms: Long): String {
    val s = (ms + 999) / 1000
    return "%d:%02d".format(s / 60, s % 60)
}

/** Залишок блокування (мс), оновлюється щосекунди; version змінюйте після кожної невдалої спроби. */
@Composable
fun rememberRemaining(l: Lockout, version: Int): Long {
    var rem by remember(version) { mutableLongStateOf(l.remainingMs()) }
    LaunchedEffect(version) {
        while (true) {
            rem = l.remainingMs()
            if (rem <= 0) break
            delay(500)
        }
    }
    return rem
}

fun helpText(): String = tr(
    "Як це працює:\n\n" +
        "• Кожна нотатка шифрується перед збереженням (AES-256). У базі на телефоні лежить лише нечитабельний набір символів.\n\n" +
        "• Шифрувальний ключ створюється з вашого PIN і \"головного ключа\" (числа). Самі PIN та ключ ніде не зберігаються.\n\n" +
        "• PIN відкриває застосунок. Ключ потрібен, щоб побачити справжній текст. Без нього видно лише зашифровані символи.\n\n" +
        "• Забули PIN або ключ — відновити нотатки НЕМОЖЛИВО. Це свідоме рішення задля безпеки.\n\n" +
        "• Перенесення: Меню → Експорт, скопіюйте текст, в іншому екземплярі застосунку Меню → Імпорт, вставте текст і введіть той самий ключ.\n\n" +
        "• Режим \"Простий зсув\" слабкий і не захищає від серйозного злому — користуйтесь \"Надійним\".",
    "How it works:\n\n" +
        "• Every note is encrypted (AES-256) before saving. The database on the phone only holds unreadable characters.\n\n" +
        "• The encryption key is derived from your PIN and the \"master key\" (a number). The PIN and key themselves are never stored.\n\n" +
        "• The PIN opens the app. The key is needed to see the real text. Without it you only see encrypted characters.\n\n" +
        "• If you forget the PIN or key, notes CANNOT be recovered. This is deliberate, for security.\n\n" +
        "• Transfer: Menu → Export, copy the text, in another copy of the app Menu → Import, paste the text and enter the same key.\n\n" +
        "• \"Simple shift\" mode is weak and does not protect against serious attacks — use \"Reliable\"."
)

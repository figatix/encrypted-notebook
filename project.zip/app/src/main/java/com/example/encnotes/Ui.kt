@file:OptIn(ExperimentalMaterial3Api::class)

package com.example.encnotes

import android.app.Activity
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.OffsetMapping
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.TransformedText
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.core.view.WindowCompat
import kotlinx.coroutines.delay

/** Переклад: читає стан мови, тому екрани оновлюються при перемиканні. */
fun tr(uk: String, en: String): String = if (App.lang == "uk") uk else en

private val LightColors = lightColorScheme(
    primary = Color(0xFFE5A50A), onPrimary = Color(0xFF2B2000),
    primaryContainer = Color(0xFFFFEFC2), onPrimaryContainer = Color(0xFF3B2E00),
    secondaryContainer = Color(0xFFFFEFC2), onSecondaryContainer = Color(0xFF3B2E00),
    background = Color(0xFFF7F6F3), onBackground = Color(0xFF1D1B16),
    surface = Color(0xFFFFFFFF), onSurface = Color(0xFF1D1B16),
    surfaceVariant = Color(0xFFEFEDE6), onSurfaceVariant = Color(0xFF6B675E),
    outline = Color(0xFFD0CCC0), outlineVariant = Color(0xFFE4E1D8),
    surfaceContainerLowest = Color(0xFFFFFFFF), surfaceContainerLow = Color(0xFFFAF9F6),
    surfaceContainer = Color(0xFFF3F1EB), surfaceContainerHigh = Color(0xFFFFFFFF),
    surfaceContainerHighest = Color(0xFFEFEDE6)
)

private val DarkColors = darkColorScheme(
    primary = Color(0xFFF2B01E), onPrimary = Color(0xFF2B2000),
    primaryContainer = Color(0xFF4A3A00), onPrimaryContainer = Color(0xFFFFE08A),
    secondaryContainer = Color(0xFF4A3A00), onSecondaryContainer = Color(0xFFFFE08A),
    background = Color(0xFF141310), onBackground = Color(0xFFE8E4DA),
    surface = Color(0xFF1F1D19), onSurface = Color(0xFFE8E4DA),
    surfaceVariant = Color(0xFF2A2822), onSurfaceVariant = Color(0xFFB5B0A3),
    outline = Color(0xFF4A473F), outlineVariant = Color(0xFF38352F),
    surfaceContainerLowest = Color(0xFF0F0E0B), surfaceContainerLow = Color(0xFF1A1814),
    surfaceContainer = Color(0xFF24221D), surfaceContainerHigh = Color(0xFF2A2822),
    surfaceContainerHighest = Color(0xFF302E27)
)

@Composable
fun AppTheme(content: @Composable () -> Unit) {
    val dark = isSystemInDarkTheme()
    val scheme = if (dark) DarkColors else LightColors
    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val w = (view.context as Activity).window
            w.statusBarColor = scheme.background.toArgb()
            w.navigationBarColor = scheme.background.toArgb()
            WindowCompat.getInsetsController(w, view).apply {
                isAppearanceLightStatusBars = !dark
                isAppearanceLightNavigationBars = !dark
            }
        }
    }
    MaterialTheme(
        colorScheme = scheme,
        shapes = Shapes(
            extraSmall = RoundedCornerShape(8.dp), small = RoundedCornerShape(12.dp),
            medium = RoundedCornerShape(20.dp), large = RoundedCornerShape(24.dp),
            extraLarge = RoundedCornerShape(28.dp)
        ),
        content = content
    )
}

/** Іконка "?" з коротким поясненням */
@Composable
fun Help(text: String) {
    var open by remember { mutableStateOf(false) }
    IconButton(onClick = { open = true }) {
        Text("?", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
    }
    if (open) {
        AlertDialog(
            onDismissRequest = { open = false },
            confirmButton = { TextButton(onClick = { open = false }) { Text("OK") } },
            text = { Text(text) }
        )
    }
}

@Composable
fun Field(
    label: String, value: String, onChange: (String) -> Unit,
    help: String? = null, secret: Boolean = false, numeric: Boolean = false,
    singleLine: Boolean = true, minLines: Int = 1, modifier: Modifier = Modifier.fillMaxWidth()
) {
    OutlinedTextField(
        value = value, onValueChange = onChange, label = { Text(label) },
        singleLine = singleLine, minLines = minLines, shape = RoundedCornerShape(16.dp),
        visualTransformation = if (secret) PasswordVisualTransformation() else VisualTransformation.None,
        keyboardOptions = KeyboardOptions(keyboardType = if (numeric) KeyboardType.NumberPassword else if (secret) KeyboardType.Password else KeyboardType.Text),
        trailingIcon = if (help != null) ({ Help(help) }) else null,
        modifier = modifier
    )
}

/** Поле без рамки (для редактора нотатки) */
@Composable
fun PlainField(
    value: String, onChange: (String) -> Unit, placeholder: String, style: TextStyle,
    modifier: Modifier = Modifier.fillMaxWidth(), singleLine: Boolean = false, minLines: Int = 1,
    transform: VisualTransformation = VisualTransformation.None
) {
    TextField(
        value = value, onValueChange = onChange, textStyle = style, singleLine = singleLine, minLines = minLines,
        placeholder = { Text(placeholder, style = style, color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f)) },
        visualTransformation = transform,
        colors = TextFieldDefaults.colors(
            focusedContainerColor = Color.Transparent, unfocusedContainerColor = Color.Transparent,
            disabledContainerColor = Color.Transparent, focusedIndicatorColor = Color.Transparent,
            unfocusedIndicatorColor = Color.Transparent, disabledIndicatorColor = Color.Transparent
        ),
        modifier = modifier
    )
}

// ---------- Підсвічування знайденого ----------
fun highlight(text: String, q: String, bg: Color): AnnotatedString {
    if (q.isBlank()) return AnnotatedString(text)
    return buildAnnotatedString {
        var i = 0
        while (true) {
            val j = text.indexOf(q, i, ignoreCase = true)
            if (j < 0) { append(text.substring(i)); break }
            append(text.substring(i, j))
            withStyle(SpanStyle(background = bg, fontWeight = FontWeight.Bold)) { append(text.substring(j, j + q.length)) }
            i = j + q.length
        }
    }
}

class HlTransform(private val q: String, private val bg: Color) : VisualTransformation {
    override fun filter(text: AnnotatedString) = TransformedText(highlight(text.text, q, bg), OffsetMapping.Identity)
}

/** Уривок тексту навколо першого збігу */
fun snippet(body: String, q: String): String {
    val flat = body.replace('\n', ' ').trim()
    if (q.isBlank()) return flat.take(140)
    val idx = flat.indexOf(q, 0, ignoreCase = true)
    if (idx < 0) return flat.take(140)
    val start = maxOf(0, idx - 30)
    return (if (start > 0) "…" else "") + flat.substring(start, minOf(flat.length, start + 140))
}

fun fmt(ms: Long): String {
    val s = (ms + 999) / 1000
    return "%d:%02d".format(s / 60, s % 60)
}

/** Залишок блокування (мс), оновлюється щосекунди; version змінюйте після кожної невдалої спроби. */
@Composable
fun rememberRemaining(l: Lockout, version: Int): Long {
    var rem by remember(version) { mutableLongStateOf(l.remainingMs()) }
    LaunchedEffect(version) {
        while (true) {
            rem = l.remainingMs()
            if (rem <= 0) break
            delay(500)
        }
    }
    return rem
}

fun helpText(): String = tr(
    "Як це працює:\n\n" +
        "• Кожна нотатка шифрується перед збереженням (AES-256). У базі на телефоні лежить лише нечитабельний набір символів.\n\n" +
        "• PIN лише відкриває застосунок. Справжній текст відкриває ключ — будь-який текст, цифри чи символи. Його питають лише коли ви відкриваєте нотатку, один раз за сеанс.\n\n" +
        "• Нову нотатку можна створити без ключа: вона шифрується одразу і відкриється лише з ключем.\n\n" +
        "• Забули PIN або ключ — відновити нотатки НЕМОЖЛИВО. Це свідоме рішення задля безпеки.\n\n" +
        "• Перенесення: Меню (⋮) → Експорт, скопіюйте текст; в іншому екземплярі застосунку Меню → Імпорт, вставте текст і введіть той самий ключ.\n\n" +
        "• Режим \"Простий зсув (Цезар)\": ключ — лише цифри, і потрібен навіть для створення нотаток. Слабкий, не захищає від серйозного злому.",
    "How it works:\n\n" +
        "• Every note is encrypted (AES-256) before saving. The database on the phone only holds unreadable characters.\n\n" +
        "• The PIN only opens the app. The real text is opened by the key — any text, digits or symbols. It is asked only when you open a note, once per session.\n\n" +
        "• A new note can be created without the key: it is encrypted at once and opens only with the key.\n\n" +
        "• If you forget the PIN or key, notes CANNOT be recovered. This is deliberate, for security.\n\n" +
        "• Transfer: Menu (⋮) → Export, copy the text; in another copy of the app Menu → Import, paste the text and enter the same key.\n\n" +
        "• \"Simple shift (Caesar)\" mode: the key is digits only and is needed even to create notes. It is weak and does not protect against serious attacks."
)
